'use client'

import { useState, useRef, useEffect } from 'react'
import { useSimulatorStore } from '@/lib/earthquake-store'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Play, Pause, Trash2, Upload, Music, Volume2, Plus } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { SavedSound } from '@/lib/earthquake-types'

interface SoundboardProps {
  onSelectSound?: (sound: SavedSound) => void
  className?: string
}

// Generate built-in sounds using Web Audio API — no files needed
function playBuiltinAudio(
  type: 'alarm' | 'siren' | 'beep' | 'rumble',
  volume: number
): { ctx: AudioContext; duration: number } | null {
  if (typeof window === 'undefined') return null
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()

  switch (type) {
    case 'beep': {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.type = 'sine'
      osc.frequency.setValueAtTime(880, ctx.currentTime)
      gain.gain.setValueAtTime(volume, ctx.currentTime)
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5)
      osc.start()
      osc.stop(ctx.currentTime + 0.5)
      return { ctx, duration: 550 }
    }
    case 'alarm': {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.type = 'square'
      gain.gain.setValueAtTime(0, ctx.currentTime)
      for (let i = 0; i < 6; i++) {
        const t = ctx.currentTime + i * 0.3
        osc.frequency.setValueAtTime(i % 2 === 0 ? 1320 : 880, t)
        gain.gain.setValueAtTime(volume * 0.35, t)
        gain.gain.setValueAtTime(0, t + 0.22)
      }
      osc.start()
      osc.stop(ctx.currentTime + 1.85)
      return { ctx, duration: 1950 }
    }
    case 'siren': {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.type = 'sawtooth'
      gain.gain.setValueAtTime(volume * 0.3, ctx.currentTime)
      for (let i = 0; i < 4; i++) {
        const t = ctx.currentTime + i * 0.75
        osc.frequency.setValueAtTime(400, t)
        osc.frequency.linearRampToValueAtTime(1200, t + 0.375)
        osc.frequency.linearRampToValueAtTime(400, t + 0.75)
      }
      osc.start()
      osc.stop(ctx.currentTime + 3)
      return { ctx, duration: 3100 }
    }
    case 'rumble': {
      const bufferSize = Math.floor(ctx.sampleRate * 3)
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate)
      const data = buffer.getChannelData(0)
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1)
      }
      const source = ctx.createBufferSource()
      source.buffer = buffer
      const filter = ctx.createBiquadFilter()
      filter.type = 'lowpass'
      filter.frequency.setValueAtTime(80, ctx.currentTime)
      filter.frequency.linearRampToValueAtTime(180, ctx.currentTime + 1.5)
      filter.frequency.linearRampToValueAtTime(60, ctx.currentTime + 3)
      const gain = ctx.createGain()
      gain.gain.setValueAtTime(0, ctx.currentTime)
      gain.gain.linearRampToValueAtTime(volume * 0.8, ctx.currentTime + 0.4)
      gain.gain.setValueAtTime(volume * 0.8, ctx.currentTime + 2)
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 3)
      source.connect(filter)
      filter.connect(gain)
      gain.connect(ctx.destination)
      source.start()
      source.stop(ctx.currentTime + 3)
      return { ctx, duration: 3200 }
    }
  }
}

export function Soundboard({ onSelectSound, className }: SoundboardProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [playingId, setPlayingId] = useState<string | null>(null)
  const [previewVolume, setPreviewVolume] = useState(0.5)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const audioCtxRef = useRef<AudioContext | null>(null)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const { savedSounds, addSound, removeSound } = useSimulatorStore()

  useEffect(() => {
    return () => {
      audioRef.current?.pause()
      audioCtxRef.current?.close().catch(() => {})
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])

  const stopAll = () => {
    audioRef.current?.pause()
    audioRef.current = null
    audioCtxRef.current?.close().catch(() => {})
    audioCtxRef.current = null
    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = null
    setPlayingId(null)
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith('audio/')) {
      alert('Please select an audio file')
      return
    }
    if (file.size > 10 * 1024 * 1024) {
      alert('File size must be less than 10MB')
      return
    }

    try {
      const reader = new FileReader()
      reader.onload = () => {
        const dataUrl = reader.result as string
        const audio = new Audio(dataUrl)
        const handleMeta = () => {
          const sound: SavedSound = {
            id: crypto.randomUUID(),
            name: file.name.replace(/\.[^/.]+$/, ''),
            dataUrl,
            duration: isFinite(audio.duration) ? audio.duration : 0,
            createdAt: Date.now(),
          }
          addSound(sound)
        }
        audio.onloadedmetadata = handleMeta
        // fallback if metadata never fires
        setTimeout(handleMeta, 2000)
      }
      reader.onerror = () => alert('Failed to read file')
      reader.readAsDataURL(file)
    } catch {
      alert('Failed to load audio file')
    }

    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const playUploadedSound = (sound: SavedSound) => {
    stopAll()
    if (playingId === sound.id) return

    const audio = new Audio(sound.dataUrl)
    audio.volume = previewVolume
    audio.onended = () => setPlayingId(null)
    audio.onerror = () => { setPlayingId(null); alert('Failed to play audio') }
    audio.play().catch(() => setPlayingId(null))
    audioRef.current = audio
    setPlayingId(sound.id)
  }

  const toggleBuiltin = (type: 'alarm' | 'siren' | 'beep' | 'rumble') => {
    stopAll()
    if (playingId === type) return

    const result = playBuiltinAudio(type, previewVolume)
    if (result) {
      audioCtxRef.current = result.ctx
      setPlayingId(type)
      timerRef.current = setTimeout(() => setPlayingId(null), result.duration)
    }
  }

  const handleSelectSound = (sound: SavedSound) => {
    onSelectSound?.(sound)
    setIsOpen(false)
  }

  const handleSelectBuiltin = (type: string) => {
    onSelectSound?.({
      id: type,
      name: type.charAt(0).toUpperCase() + type.slice(1),
      dataUrl: '',
      duration: 3,
      createdAt: 0,
    })
    setIsOpen(false)
  }

  const formatDuration = (s: number) => {
    if (!s || !isFinite(s)) return '--'
    const m = Math.floor(s / 60)
    return `${m}:${Math.floor(s % 60).toString().padStart(2, '0')}`
  }

  const builtins = [
    { id: 'beep' as const, label: 'Beep', desc: '0.5s tone' },
    { id: 'alarm' as const, label: 'Alarm', desc: '1.8s alternating' },
    { id: 'siren' as const, label: 'Siren', desc: '3s sweep' },
    { id: 'rumble' as const, label: 'Rumble', desc: '3s low rumble' },
  ]

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) stopAll(); setIsOpen(open) }}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className={className}>
          <Music className="w-4 h-4 mr-2" />
          Soundboard
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Soundboard</DialogTitle>
          <DialogDescription>
            Preview and assign audio to timeline events
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4 flex-1 overflow-hidden">
          {/* Upload */}
          <div className="flex items-center gap-4 p-3 border border-dashed border-border rounded-lg">
            <input ref={fileInputRef} type="file" accept="audio/*" onChange={handleFileUpload} className="hidden" />
            <Button onClick={() => fileInputRef.current?.click()} size="sm">
              <Upload className="w-4 h-4 mr-2" />
              Import Audio
            </Button>
            <span className="text-xs text-muted-foreground">MP3, WAV, OGG, M4A · max 10MB · stored in memory</span>
          </div>

          {/* Volume */}
          <div className="flex items-center gap-3">
            <Volume2 className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <Label className="text-sm whitespace-nowrap">Preview Volume</Label>
            <Slider
              value={[previewVolume]}
              min={0} max={1} step={0.05}
              onValueChange={([v]) => {
                setPreviewVolume(v)
                if (audioRef.current) audioRef.current.volume = v
              }}
              className="w-28"
            />
            <span className="text-xs text-muted-foreground w-8 text-right">{Math.round(previewVolume * 100)}%</span>
          </div>

          {/* Built-ins */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Built-in Sounds</Label>
            <div className="grid grid-cols-2 gap-2">
              {builtins.map(({ id, label, desc }) => (
                <div
                  key={id}
                  className={cn(
                    'flex items-center gap-2 p-2 rounded-lg border border-border hover:bg-muted/50 transition-colors',
                    playingId === id && 'bg-primary/10 border-primary'
                  )}
                >
                  <Button variant="ghost" size="icon" onClick={() => toggleBuiltin(id)} className="h-7 w-7 flex-shrink-0">
                    {playingId === id ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                  </Button>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{label}</p>
                    <p className="text-xs text-muted-foreground">{desc}</p>
                  </div>
                  {onSelectSound && (
                    <Button variant="outline" size="sm" className="h-6 text-xs px-2" onClick={() => handleSelectBuiltin(id)}>
                      Use
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Imported sounds */}
          <div className="flex-1 overflow-y-auto">
            {savedSounds.length > 0 ? (
              <>
                <Label className="text-sm font-medium mb-2 block">Your Sounds ({savedSounds.length})</Label>
                <div className="grid gap-2">
                  {savedSounds.map((sound) => (
                    <div
                      key={sound.id}
                      className={cn(
                        'flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors',
                        playingId === sound.id && 'bg-primary/10 border-primary'
                      )}
                    >
                      <Button variant="ghost" size="icon" onClick={() => playUploadedSound(sound)} className="h-8 w-8 flex-shrink-0">
                        {playingId === sound.id ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      </Button>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate text-sm">{sound.name}</p>
                        <p className="text-xs text-muted-foreground">{formatDuration(sound.duration)}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        {onSelectSound && (
                          <Button variant="outline" size="sm" className="h-7 text-xs px-2" onClick={() => handleSelectSound(sound)}>
                            <Plus className="w-3 h-3 mr-1" />Use
                          </Button>
                        )}
                        <Button
                          variant="ghost" size="icon"
                          onClick={() => { if (playingId === sound.id) stopAll(); removeSound(sound.id) }}
                          className="h-8 w-8 text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-20 text-muted-foreground">
                <p className="text-sm">No imported sounds yet</p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
