'use client'

import { useEffect } from 'react'
import { useSimulatorStore } from '@/lib/earthquake-store'
import { cn } from '@/lib/utils'
import { AlertTriangle, Waves, AlertCircle, Activity } from 'lucide-react'

export function WarningAlert() {
  const { events, currentTime, setActiveWarnings, activeWarnings } = useSimulatorStore()

  // Update active warnings based on current time
  useEffect(() => {
    const activeWarningEvents = events.filter(
      e => e.type === 'warning' && 
      currentTime >= e.startTime && 
      currentTime < e.startTime + e.duration
    )

    const warnings = activeWarningEvents.map(e => {
      if (e.type !== 'warning') return null
      return {
        id: e.id,
        type: e.warningType,
        severity: e.severity,
        title: e.title,
        message: e.message,
        active: true,
      }
    }).filter(Boolean) as NonNullable<typeof activeWarnings[0]>[]

    // Only update if warnings changed
    if (JSON.stringify(warnings) !== JSON.stringify(activeWarnings)) {
      setActiveWarnings(warnings)
    }
  }, [events, currentTime, setActiveWarnings, activeWarnings])

  // Find active warning events for display
  const activeWarningEvents = events.filter(
    e => e.type === 'warning' && 
    currentTime >= e.startTime && 
    currentTime < e.startTime + e.duration
  )

  if (activeWarningEvents.length === 0) return null

  return (
    <>
      {activeWarningEvents.map((event) => {
        if (event.type !== 'warning') return null

        const progress = (currentTime - event.startTime) / event.duration
        const fadeIn = Math.min(1, progress * 10)
        const fadeOut = Math.min(1, (1 - progress) * 10)
        const opacity = Math.min(fadeIn, fadeOut)

        const getIcon = () => {
          switch (event.warningType) {
            case 'tsunami':
              return <Waves className="w-8 h-8" />
            case 'eew':
              return <AlertTriangle className="w-8 h-8" />
            case 'intensity-alert':
              return <AlertCircle className="w-8 h-8" />
            case 'long-period':
              return <Activity className="w-8 h-8" />
            default:
              return <AlertTriangle className="w-8 h-8" />
          }
        }

        const severityStyles = {
          advisory: {
            container: 'bg-yellow-900/95 border-yellow-500',
            text: 'text-yellow-100',
            icon: 'text-yellow-400',
          },
          warning: {
            container: 'bg-orange-900/95 border-orange-500',
            text: 'text-orange-100',
            icon: 'text-orange-400',
          },
          emergency: {
            container: 'bg-red-900/95 border-red-500 animate-pulse',
            text: 'text-red-100',
            icon: 'text-red-400',
          },
        }

        const styles = severityStyles[event.severity]

        return (
          <div
            key={event.id}
            className={cn(
              'absolute top-4 left-1/2 -translate-x-1/2 w-[90%] max-w-xl',
              'border-2 rounded-lg shadow-2xl overflow-hidden',
              styles.container
            )}
            style={{ opacity }}
          >
            {/* Flashing header for emergency */}
            {event.severity === 'emergency' && (
              <div className="bg-red-600 py-1.5 flex items-center justify-center gap-2">
                <span className="text-white font-bold text-sm uppercase tracking-widest animate-pulse">
                  EMERGENCY ALERT
                </span>
              </div>
            )}

            <div className="p-4 flex items-start gap-4">
              <div className={cn('flex-shrink-0', styles.icon)}>
                {getIcon()}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className={cn('font-bold text-lg uppercase tracking-wide', styles.text)}>
                  {event.title}
                </h3>
                <p className={cn('mt-1 text-sm', styles.text, 'opacity-90')}>
                  {event.message}
                </p>
                {event.regions && event.regions.length > 0 && (
                  <p className={cn('mt-2 text-xs', styles.text, 'opacity-70')}>
                    Affected areas: {event.regions.join(', ')}
                  </p>
                )}
              </div>
            </div>

            {/* Severity indicator bar */}
            <div className={cn(
              'h-1',
              event.severity === 'emergency' ? 'bg-red-500' :
              event.severity === 'warning' ? 'bg-orange-500' : 'bg-yellow-500'
            )} />
          </div>
        )
      })}
    </>
  )
}
