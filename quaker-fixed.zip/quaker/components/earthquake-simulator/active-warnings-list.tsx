'use client'

import { useSimulatorStore } from '@/lib/earthquake-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertTriangle, AlertCircle, Info, Waves } from 'lucide-react'
import { cn } from '@/lib/utils'

export function ActiveWarningsList() {
  const { activeWarnings } = useSimulatorStore()

  if (activeWarnings.length === 0) {
    return (
      <Card className="bg-sidebar-accent border-sidebar-border">
        <CardHeader className="py-2 px-3">
          <CardTitle className="text-xs font-medium text-sidebar-foreground/70 uppercase tracking-wide">
            Warnings
          </CardTitle>
        </CardHeader>
        <CardContent className="py-2 px-3">
          <div className="text-xs text-sidebar-foreground/50 text-center py-2">
            No active warnings
          </div>
        </CardContent>
      </Card>
    )
  }

  const getWarningIcon = (type: string) => {
    switch (type) {
      case 'tsunami':
        return <Waves className="w-4 h-4" />
      case 'eew':
        return <AlertTriangle className="w-4 h-4" />
      case 'intensity-alert':
        return <AlertCircle className="w-4 h-4" />
      default:
        return <Info className="w-4 h-4" />
    }
  }

  const getSeverityStyles = (severity: string) => {
    switch (severity) {
      case 'emergency':
        return 'bg-red-900/50 border-red-500 text-red-100'
      case 'warning':
        return 'bg-orange-900/50 border-orange-500 text-orange-100'
      case 'advisory':
        return 'bg-yellow-900/50 border-yellow-500 text-yellow-100'
      default:
        return 'bg-sidebar-accent border-sidebar-border text-sidebar-foreground'
    }
  }

  return (
    <Card className="bg-sidebar-accent border-sidebar-border">
      <CardHeader className="py-2 px-3">
        <CardTitle className="text-xs font-medium text-sidebar-foreground/70 uppercase tracking-wide flex items-center gap-2">
          <AlertTriangle className="w-3 h-3 text-yellow-500" />
          Active Warnings ({activeWarnings.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="py-1 px-3 space-y-2">
        {activeWarnings.map((warning) => (
          <div
            key={warning.id}
            className={cn(
              'p-2 rounded-md border-l-4 transition-all',
              getSeverityStyles(warning.severity),
              warning.severity === 'emergency' && 'animate-pulse'
            )}
          >
            <div className="flex items-center gap-2 mb-1">
              {getWarningIcon(warning.type)}
              <span className="font-semibold text-xs uppercase">{warning.title}</span>
            </div>
            <p className="text-[10px] opacity-90 leading-tight">{warning.message}</p>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
