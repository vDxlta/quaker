'use client'

import { useSimulatorStore } from '@/lib/earthquake-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Activity } from 'lucide-react'

export function WaveStatusDisplay() {
  const {
    pWaveRadius,
    sWaveRadius,
    pWaveSpeed,
    sWaveSpeed,
    showPWave,
    showSWave,
    currentTime,
    earthquakeInfo,
  } = useSimulatorStore()

  const timeSinceOrigin = currentTime - earthquakeInfo.originTime
  const hasStarted = timeSinceOrigin >= 0

  return (
    <Card className="bg-sidebar-accent border-sidebar-border">
      <CardHeader className="py-2 px-3">
        <CardTitle className="text-xs font-medium text-sidebar-foreground/70 uppercase tracking-wide flex items-center gap-2">
          <Activity className="w-3 h-3" />
          Wave Propagation
        </CardTitle>
      </CardHeader>
      <CardContent className="py-2 px-3 space-y-3">
        {!hasStarted ? (
          <div className="text-xs text-sidebar-foreground/50 text-center py-2">
            Waiting for earthquake origin...
          </div>
        ) : (
          <>
            {/* P-Wave Status */}
            {showPWave && (
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-0.5 bg-blue-400 rounded" style={{ borderStyle: 'dashed' }} />
                    <span className="text-xs text-blue-400">P-Wave</span>
                  </div>
                  <span className="text-xs font-mono text-sidebar-foreground">
                    {pWaveRadius.toFixed(0)} km
                  </span>
                </div>
                <div className="w-full h-1.5 bg-sidebar rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-400 transition-all duration-100"
                    style={{ width: `${Math.min(100, (pWaveRadius / 500) * 100)}%` }}
                  />
                </div>
                <div className="text-[10px] text-sidebar-foreground/50">
                  Speed: {pWaveSpeed.toFixed(1)} km/s
                </div>
              </div>
            )}

            {/* S-Wave Status */}
            {showSWave && (
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-0.5 bg-red-400 rounded" />
                    <span className="text-xs text-red-400">S-Wave</span>
                  </div>
                  <span className="text-xs font-mono text-sidebar-foreground">
                    {sWaveRadius.toFixed(0)} km
                  </span>
                </div>
                <div className="w-full h-1.5 bg-sidebar rounded-full overflow-hidden">
                  <div
                    className="h-full bg-red-400 transition-all duration-100"
                    style={{ width: `${Math.min(100, (sWaveRadius / 500) * 100)}%` }}
                  />
                </div>
                <div className="text-[10px] text-sidebar-foreground/50">
                  Speed: {sWaveSpeed.toFixed(1)} km/s
                </div>
              </div>
            )}

            {/* Wave difference indicator */}
            {showPWave && showSWave && pWaveRadius > 0 && (
              <div className="pt-2 border-t border-sidebar-border">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-sidebar-foreground/70">P-S Separation</span>
                  <span className="font-mono text-sidebar-foreground">
                    {(pWaveRadius - sWaveRadius).toFixed(0)} km
                  </span>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}
