'use client'

import { useState, useRef } from 'react'
import { useSimulatorStore } from '@/lib/earthquake-store'
import { VideoRecorder, downloadBlob, formatFileSize } from '@/lib/video-recorder'
import { RESOLUTION_MAP } from '@/lib/earthquake-types'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog'
import { Switch } from '@/components/ui/switch'
import {
  Download,
  Video,
  Loader2,
  CheckCircle,
  AlertCircle,
} from 'lucide-react'
import type { ExportSettings } from '@/lib/earthquake-types'

interface ExportControlsProps {
  canvasRef: React.RefObject<HTMLCanvasElement>
}

export function ExportControls({ canvasRef }: ExportControlsProps) {
  const {
    exportSettings,
    setExportSettings,
    isRecording,
    setIsRecording,
    exportProgress,
    setExportProgress,
    duration,
    play,
    pause,
    stop,
    seek,
    currentTime,
  } = useSimulatorStore()

  const [isExporting, setIsExporting] = useState(false)
  const [exportStatus, setExportStatus] = useState<'idle' | 'recording' | 'processing' | 'done' | 'error'>('idle')
  const [exportedBlob, setExportedBlob] = useState<Blob | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  
  const recorderRef = useRef<VideoRecorder | null>(null)
  const animationRef = useRef<number | null>(null)

  const handleExport = async () => {
    if (!canvasRef.current) {
      setExportStatus('error')
      return
    }

    setIsExporting(true)
    setExportStatus('recording')
    setExportProgress(0)
    setIsRecording(true)

    // Reset to beginning
    seek(0)

    // Create and start recorder
    recorderRef.current = new VideoRecorder(canvasRef.current, exportSettings)
    await recorderRef.current.start()

    // Start playback and track progress
    play()

    const startTime = Date.now()
    const totalDuration = duration * 1000 // Convert to ms

    const checkProgress = () => {
      const elapsed = Date.now() - startTime
      const progress = Math.min(100, (elapsed / totalDuration) * 100)
      setExportProgress(progress)

      if (currentTime >= duration - 0.1 || elapsed >= totalDuration) {
        // Recording complete
        finishExport()
      } else {
        animationRef.current = requestAnimationFrame(checkProgress)
      }
    }

    animationRef.current = requestAnimationFrame(checkProgress)
  }

  const finishExport = async () => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
    }

    pause()
    setExportStatus('processing')

    try {
      if (recorderRef.current) {
        const blob = await recorderRef.current.stop()
        setExportedBlob(blob)
        setExportStatus('done')
      }
    } catch (error) {
      console.error('Export error:', error)
      setExportStatus('error')
    }

    setIsRecording(false)
    setIsExporting(false)
    stop()
  }

  const handleDownload = () => {
    if (exportedBlob) {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
      downloadBlob(exportedBlob, `earthquake-simulation-${timestamp}.webm`)
    }
  }

  const handleCancel = () => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
    }
    if (recorderRef.current) {
      recorderRef.current.stop().catch(() => {})
    }
    pause()
    stop()
    setIsRecording(false)
    setIsExporting(false)
    setExportStatus('idle')
    setExportProgress(0)
  }

  const resetExport = () => {
    setExportStatus('idle')
    setExportedBlob(null)
    setExportProgress(0)
  }

  const resolution = RESOLUTION_MAP[exportSettings.resolution]

  return (
    <Dialog open={dialogOpen} onOpenChange={(open) => {
      setDialogOpen(open)
      if (!open) resetExport()
    }}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Video className="w-4 h-4 mr-2" />
          Export Video
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Export Video</DialogTitle>
          <DialogDescription>
            Record your earthquake simulation as a video file.
          </DialogDescription>
        </DialogHeader>

        {exportStatus === 'idle' && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Resolution</Label>
              <Select
                value={exportSettings.resolution}
                onValueChange={(value) => setExportSettings({ resolution: value as ExportSettings['resolution'] })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="720p">720p (1280x720)</SelectItem>
                  <SelectItem value="1080p">1080p (1920x1080)</SelectItem>
                  <SelectItem value="1440p">1440p (2560x1440)</SelectItem>
                  <SelectItem value="4k">4K (3840x2160)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Frame Rate</Label>
              <Select
                value={exportSettings.frameRate.toString()}
                onValueChange={(value) => setExportSettings({ frameRate: parseInt(value) as 30 | 60 })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 FPS</SelectItem>
                  <SelectItem value="60">60 FPS</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <Label>Include Audio</Label>
              <Switch
                checked={exportSettings.includeAudio}
                onCheckedChange={(checked) => setExportSettings({ includeAudio: checked })}
              />
            </div>

            <div className="text-sm text-muted-foreground bg-muted p-3 rounded-lg">
              <p>Duration: {duration}s</p>
              <p>Resolution: {resolution.width}x{resolution.height}</p>
              <p>Format: WebM (VP9)</p>
            </div>
          </div>
        )}

        {(exportStatus === 'recording' || exportStatus === 'processing') && (
          <div className="py-8 space-y-4">
            <div className="flex items-center justify-center">
              <Loader2 className="w-12 h-12 animate-spin text-primary" />
            </div>
            <div className="text-center">
              <p className="font-medium">
                {exportStatus === 'recording' ? 'Recording...' : 'Processing video...'}
              </p>
              <p className="text-sm text-muted-foreground">
                {exportStatus === 'recording' 
                  ? 'Please wait while the simulation is recorded.'
                  : 'Finalizing the video file...'}
              </p>
            </div>
            {exportStatus === 'recording' && (
              <Progress value={exportProgress} className="w-full" />
            )}
            <p className="text-center text-sm text-muted-foreground">
              {exportProgress.toFixed(0)}% complete
            </p>
          </div>
        )}

        {exportStatus === 'done' && exportedBlob && (
          <div className="py-8 space-y-4">
            <div className="flex items-center justify-center">
              <CheckCircle className="w-12 h-12 text-green-500" />
            </div>
            <div className="text-center">
              <p className="font-medium">Export Complete!</p>
              <p className="text-sm text-muted-foreground">
                File size: {formatFileSize(exportedBlob.size)}
              </p>
            </div>
          </div>
        )}

        {exportStatus === 'error' && (
          <div className="py-8 space-y-4">
            <div className="flex items-center justify-center">
              <AlertCircle className="w-12 h-12 text-destructive" />
            </div>
            <div className="text-center">
              <p className="font-medium text-destructive">Export Failed</p>
              <p className="text-sm text-muted-foreground">
                An error occurred during the export process.
              </p>
            </div>
          </div>
        )}

        <DialogFooter>
          {exportStatus === 'idle' && (
            <>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleExport}>
                <Video className="w-4 h-4 mr-2" />
                Start Export
              </Button>
            </>
          )}
          
          {(exportStatus === 'recording' || exportStatus === 'processing') && (
            <Button variant="destructive" onClick={handleCancel}>
              Cancel Export
            </Button>
          )}

          {exportStatus === 'done' && (
            <>
              <Button variant="outline" onClick={resetExport}>
                Export Again
              </Button>
              <Button onClick={handleDownload}>
                <Download className="w-4 h-4 mr-2" />
                Download Video
              </Button>
            </>
          )}

          {exportStatus === 'error' && (
            <Button onClick={resetExport}>
              Try Again
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
