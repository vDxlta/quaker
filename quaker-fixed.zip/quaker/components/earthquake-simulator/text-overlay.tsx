'use client'

import { useSimulatorStore } from '@/lib/earthquake-store'
import { cn } from '@/lib/utils'

export function TextOverlay() {
  const { events, currentTime } = useSimulatorStore()

  // Find active text events at current time
  const activeTextEvents = events.filter(
    e => e.type === 'text' && 
    currentTime >= e.startTime && 
    currentTime < e.startTime + e.duration
  )

  if (activeTextEvents.length === 0) return null

  return (
    <>
      {activeTextEvents.map((event) => {
        if (event.type !== 'text') return null

        const progress = (currentTime - event.startTime) / event.duration
        const fadeIn = Math.min(1, progress * 5) // Fade in over first 20%
        const fadeOut = Math.min(1, (1 - progress) * 5) // Fade out over last 20%
        const opacity = Math.min(fadeIn, fadeOut)

        const positionClasses = {
          top: 'top-8 left-1/2 -translate-x-1/2',
          center: 'top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2',
          bottom: 'bottom-8 left-1/2 -translate-x-1/2',
          custom: '',
        }

        const fontSizeClasses = {
          small: 'text-lg',
          medium: 'text-2xl',
          large: 'text-4xl',
          xlarge: 'text-6xl',
        }

        const styleClasses = {
          normal: 'bg-black/70 text-white',
          urgent: 'bg-red-600/90 text-white animate-pulse',
          info: 'bg-blue-600/90 text-white',
          warning: 'bg-yellow-500/90 text-black',
        }

        return (
          <div
            key={event.id}
            className={cn(
              'absolute px-6 py-3 rounded-lg font-bold text-center transition-all duration-200',
              positionClasses[event.position],
              fontSizeClasses[event.fontSize],
              styleClasses[event.style]
            )}
            style={{
              opacity,
              ...(event.position === 'custom' && event.customPosition
                ? { left: `${event.customPosition.x}%`, top: `${event.customPosition.y}%` }
                : {}),
            }}
          >
            {event.text}
          </div>
        )
      })}
    </>
  )
}
