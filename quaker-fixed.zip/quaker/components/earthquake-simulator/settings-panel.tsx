'use client'

import { useState } from 'react'
import { useSimulatorStore } from '@/lib/earthquake-store'
import { PRESET_SCALES, CUSTOM_SCALE_TEMPLATE } from '@/lib/intensity-scales'
import { DEFAULT_P_WAVE_SPEED, DEFAULT_S_WAVE_SPEED } from '@/lib/wave-calculations'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Settings, Plus, Trash2, MapPin } from 'lucide-react'
import type { Sensor, IntensityScale, IntensityLevel } from '@/lib/earthquake-types'

export function SettingsPanel() {
  const {
    settingsPanelOpen,
    setSettingsPanelOpen,
    earthquakeInfo,
    setEarthquakeInfo,
    duration,
    setDuration,
    intensityScale,
    setIntensityScale,
    pWaveSpeed,
    sWaveSpeed,
    setWaveSpeeds,
    showPWave,
    showSWave,
    setShowWaves,
    sensors,
    addSensor,
    updateSensor,
    removeSensor,
    mapCenter,
    setMapCenter,
    mapZoom,
    setMapZoom,
  } = useSimulatorStore()

  const [customScale, setCustomScale] = useState<IntensityScale>(CUSTOM_SCALE_TEMPLATE)
  const [newSensor, setNewSensor] = useState<Partial<Sensor>>({
    name: '',
    position: { lat: 35.6762, lng: 139.6503 },
    isRealSensor: false,
  })

  const handleAddSensor = () => {
    if (!newSensor.name) return
    
    addSensor({
      id: crypto.randomUUID(),
      name: newSensor.name,
      position: newSensor.position ?? { lat: 35.6762, lng: 139.6503 },
      isRealSensor: newSensor.isRealSensor ?? false,
      stationCode: newSensor.stationCode,
    })
    
    setNewSensor({
      name: '',
      position: { lat: earthquakeInfo.epicenter.lat, lng: earthquakeInfo.epicenter.lng },
      isRealSensor: false,
    })
  }

  const handleScaleChange = (scaleId: string) => {
    if (scaleId === 'custom') {
      setIntensityScale(customScale)
    } else {
      const preset = PRESET_SCALES.find(s => s.id === scaleId)
      if (preset) {
        setIntensityScale(preset)
      }
    }
  }

  const updateCustomScaleLevel = (index: number, updates: Partial<IntensityLevel>) => {
    const newLevels = [...customScale.levels]
    newLevels[index] = { ...newLevels[index], ...updates }
    const newScale = { ...customScale, levels: newLevels }
    setCustomScale(newScale)
    if (intensityScale.id === 'custom') {
      setIntensityScale(newScale)
    }
  }

  const addCustomScaleLevel = () => {
    const maxValue = Math.max(...customScale.levels.map(l => l.value))
    const newLevel: IntensityLevel = {
      value: maxValue + 1,
      label: `Level ${customScale.levels.length + 1}`,
      color: '#ff0000',
      description: 'Description',
    }
    const newScale = { ...customScale, levels: [...customScale.levels, newLevel] }
    setCustomScale(newScale)
    if (intensityScale.id === 'custom') {
      setIntensityScale(newScale)
    }
  }

  const removeCustomScaleLevel = (index: number) => {
    const newLevels = customScale.levels.filter((_, i) => i !== index)
    const newScale = { ...customScale, levels: newLevels }
    setCustomScale(newScale)
    if (intensityScale.id === 'custom') {
      setIntensityScale(newScale)
    }
  }

  return (
    <Sheet open={settingsPanelOpen} onOpenChange={setSettingsPanelOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon">
          <Settings className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-96 overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Scenario Settings</SheetTitle>
        </SheetHeader>

        <Tabs defaultValue="earthquake" className="mt-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="earthquake">Quake</TabsTrigger>
            <TabsTrigger value="sensors">Sensors</TabsTrigger>
            <TabsTrigger value="scale">Scale</TabsTrigger>
            <TabsTrigger value="map">Map</TabsTrigger>
          </TabsList>

          {/* Earthquake Settings */}
          <TabsContent value="earthquake" className="space-y-4">
            <div className="space-y-2">
              <Label>Location Name</Label>
              <Input
                value={earthquakeInfo.locationName}
                onChange={(e) => setEarthquakeInfo({ locationName: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Magnitude (M{earthquakeInfo.magnitude.toFixed(1)})</Label>
              <Slider
                value={[earthquakeInfo.magnitude]}
                min={1}
                max={10}
                step={0.1}
                onValueChange={([value]) => setEarthquakeInfo({ magnitude: value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Depth ({earthquakeInfo.depth} km)</Label>
              <Slider
                value={[earthquakeInfo.depth]}
                min={1}
                max={700}
                step={1}
                onValueChange={([value]) => setEarthquakeInfo({ depth: value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-2">
                <Label>Epicenter Lat</Label>
                <Input
                  type="number"
                  value={earthquakeInfo.epicenter.lat}
                  onChange={(e) => setEarthquakeInfo({
                    epicenter: { ...earthquakeInfo.epicenter, lat: parseFloat(e.target.value) }
                  })}
                  step={0.001}
                />
              </div>
              <div className="space-y-2">
                <Label>Epicenter Lng</Label>
                <Input
                  type="number"
                  value={earthquakeInfo.epicenter.lng}
                  onChange={(e) => setEarthquakeInfo({
                    epicenter: { ...earthquakeInfo.epicenter, lng: parseFloat(e.target.value) }
                  })}
                  step={0.001}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Origin Time (seconds)</Label>
              <Input
                type="number"
                value={earthquakeInfo.originTime}
                onChange={(e) => setEarthquakeInfo({ originTime: parseFloat(e.target.value) })}
                step={0.1}
              />
            </div>

            <div className="space-y-2">
              <Label>Scenario Duration ({duration}s)</Label>
              <Slider
                value={[duration]}
                min={30}
                max={600}
                step={10}
                onValueChange={([value]) => setDuration(value)}
              />
            </div>

            <div className="border-t pt-4 mt-4 space-y-4">
              <h4 className="font-medium text-sm">Wave Propagation</h4>
              
              <div className="space-y-2">
                <Label>P-Wave Speed ({pWaveSpeed.toFixed(1)} km/s)</Label>
                <Slider
                  value={[pWaveSpeed]}
                  min={4}
                  max={10}
                  step={0.1}
                  onValueChange={([value]) => setWaveSpeeds(value, sWaveSpeed)}
                />
              </div>

              <div className="space-y-2">
                <Label>S-Wave Speed ({sWaveSpeed.toFixed(1)} km/s)</Label>
                <Slider
                  value={[sWaveSpeed]}
                  min={2}
                  max={6}
                  step={0.1}
                  onValueChange={([value]) => setWaveSpeeds(pWaveSpeed, value)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Show P-Wave</Label>
                <Switch
                  checked={showPWave}
                  onCheckedChange={(checked) => setShowWaves(checked, showSWave)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Show S-Wave</Label>
                <Switch
                  checked={showSWave}
                  onCheckedChange={(checked) => setShowWaves(showPWave, checked)}
                />
              </div>
            </div>
          </TabsContent>

          {/* Sensors Settings */}
          <TabsContent value="sensors" className="space-y-4">
            <div className="border rounded-lg p-3 space-y-3">
              <h4 className="font-medium text-sm">Add Sensor</h4>
              
              <div className="space-y-2">
                <Label>Name</Label>
                <Input
                  value={newSensor.name ?? ''}
                  onChange={(e) => setNewSensor(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Tokyo Station"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-2">
                  <Label>Latitude</Label>
                  <Input
                    type="number"
                    value={newSensor.position?.lat ?? 35.6762}
                    onChange={(e) => setNewSensor(prev => ({
                      ...prev,
                      position: { ...prev.position!, lat: parseFloat(e.target.value) }
                    }))}
                    step={0.001}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Longitude</Label>
                  <Input
                    type="number"
                    value={newSensor.position?.lng ?? 139.6503}
                    onChange={(e) => setNewSensor(prev => ({
                      ...prev,
                      position: { ...prev.position!, lng: parseFloat(e.target.value) }
                    }))}
                    step={0.001}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Label>Real-world Sensor</Label>
                <Switch
                  checked={newSensor.isRealSensor ?? false}
                  onCheckedChange={(checked) => setNewSensor(prev => ({ ...prev, isRealSensor: checked }))}
                />
              </div>

              {newSensor.isRealSensor && (
                <div className="space-y-2">
                  <Label>Station Code</Label>
                  <Input
                    value={newSensor.stationCode ?? ''}
                    onChange={(e) => setNewSensor(prev => ({ ...prev, stationCode: e.target.value }))}
                    placeholder="e.g., TK.TOKYO"
                  />
                </div>
              )}

              <Button onClick={handleAddSensor} className="w-full" disabled={!newSensor.name}>
                <Plus className="w-4 h-4 mr-2" />
                Add Sensor
              </Button>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium text-sm">Sensors ({sensors.length})</h4>
              {sensors.length === 0 ? (
                <p className="text-sm text-muted-foreground">No sensors added yet.</p>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {sensors.map((sensor) => (
                    <div
                      key={sensor.id}
                      className="flex items-center justify-between p-2 bg-muted rounded-lg"
                    >
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">{sensor.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {sensor.position.lat.toFixed(3)}, {sensor.position.lng.toFixed(3)}
                          </p>
                        </div>
                        {sensor.isRealSensor && (
                          <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded">
                            Real
                          </span>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeSensor(sensor.id)}
                        className="h-7 w-7"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* Scale Settings */}
          <TabsContent value="scale" className="space-y-4">
            <div className="space-y-2">
              <Label>Intensity Scale</Label>
              <Select
                value={intensityScale.id}
                onValueChange={handleScaleChange}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRESET_SCALES.map((scale) => (
                    <SelectItem key={scale.id} value={scale.id}>
                      {scale.name}
                    </SelectItem>
                  ))}
                  <SelectItem value="custom">Custom Scale</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Scale preview */}
            <div className="space-y-2">
              <Label>Scale Levels</Label>
              <div className="flex gap-1">
                {intensityScale.levels.map((level, i) => (
                  <div
                    key={i}
                    className="flex-1 h-8 rounded flex items-center justify-center text-xs font-medium"
                    style={{ backgroundColor: level.color, color: '#000' }}
                    title={level.description}
                  >
                    {level.label}
                  </div>
                ))}
              </div>
            </div>

            {/* Custom scale editor */}
            {intensityScale.id === 'custom' && (
              <div className="border-t pt-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-sm">Edit Custom Scale</h4>
                  <Button size="sm" variant="outline" onClick={addCustomScaleLevel}>
                    <Plus className="w-3 h-3 mr-1" />
                    Add Level
                  </Button>
                </div>

                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {customScale.levels.map((level, index) => (
                    <div key={index} className="border rounded-lg p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Level {index + 1}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeCustomScaleLevel(index)}
                          disabled={customScale.levels.length <= 2}
                          className="h-6 w-6"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">Value</Label>
                          <Input
                            type="number"
                            value={level.value}
                            onChange={(e) => updateCustomScaleLevel(index, { value: parseFloat(e.target.value) })}
                            className="h-8"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Label</Label>
                          <Input
                            value={level.label}
                            onChange={(e) => updateCustomScaleLevel(index, { label: e.target.value })}
                            className="h-8"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">Color</Label>
                          <Input
                            type="color"
                            value={level.color}
                            onChange={(e) => updateCustomScaleLevel(index, { color: e.target.value })}
                            className="h-8 p-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Description</Label>
                          <Input
                            value={level.description}
                            onChange={(e) => updateCustomScaleLevel(index, { description: e.target.value })}
                            className="h-8"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          {/* Map Settings */}
          <TabsContent value="map" className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-2">
                <Label>Center Latitude</Label>
                <Input
                  type="number"
                  value={mapCenter.lat}
                  onChange={(e) => setMapCenter({ ...mapCenter, lat: parseFloat(e.target.value) })}
                  step={0.001}
                />
              </div>
              <div className="space-y-2">
                <Label>Center Longitude</Label>
                <Input
                  type="number"
                  value={mapCenter.lng}
                  onChange={(e) => setMapCenter({ ...mapCenter, lng: parseFloat(e.target.value) })}
                  step={0.001}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Zoom Level ({mapZoom})</Label>
              <Slider
                value={[mapZoom]}
                min={3}
                max={15}
                step={0.5}
                onValueChange={([value]) => setMapZoom(value)}
              />
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                setMapCenter(earthquakeInfo.epicenter)
              }}
            >
              <MapPin className="w-4 h-4 mr-2" />
              Center on Epicenter
            </Button>
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  )
}
