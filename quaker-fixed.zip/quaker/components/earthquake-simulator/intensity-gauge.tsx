'use client'

import { useSimulatorStore } from '@/lib/earthquake-store'
import { getIntensityColor, getIntensityLabel } from '@/lib/intensity-scales'

interface IntensityGaugeProps {
  className?: string
}

export function IntensityGauge({ className }: IntensityGaugeProps) {
  const { currentIntensity, intensityScale } = useSimulatorStore()

  const color = getIntensityColor(intensityScale, currentIntensity)
  const label = getIntensityLabel(intensityScale, currentIntensity)
  
  // Get max intensity for scale
  const maxIntensity = Math.max(...intensityScale.levels.map(l => l.value))
  const fillPercent = (currentIntensity / maxIntensity) * 100

  return (
    <div className={`flex flex-col items-center gap-3 p-4 ${className}`}>
      {/* Main intensity display */}
      <div
        className="w-24 h-24 rounded-xl flex flex-col items-center justify-center shadow-lg transition-colors duration-200"
        style={{ backgroundColor: color }}
      >
        <span className="text-3xl font-bold text-black">{label}</span>
        <span className="text-xs text-black/70">{currentIntensity.toFixed(1)}</span>
      </div>

      {/* Scale indicator */}
      <div className="w-full max-w-[120px]">
        <div className="text-xs text-muted-foreground text-center mb-2">
          {intensityScale.name}
        </div>
        
        {/* Vertical bar gauge */}
        <div className="relative h-40 w-8 mx-auto bg-muted rounded-lg overflow-hidden">
          {/* Fill */}
          <div
            className="absolute bottom-0 left-0 right-0 transition-all duration-200"
            style={{
              height: `${fillPercent}%`,
              backgroundColor: color,
            }}
          />
          
          {/* Scale markers */}
          {intensityScale.levels.map((level, index) => {
            const position = (level.value / maxIntensity) * 100
            return (
              <div
                key={index}
                className="absolute left-full ml-1 flex items-center gap-1"
                style={{ bottom: `${position}%`, transform: 'translateY(50%)' }}
              >
                <div className="w-1.5 h-0.5 bg-muted-foreground/30" />
                <span
                  className="text-[9px] font-medium"
                  style={{ color: level.color }}
                >
                  {level.label}
                </span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Current level description */}
      <div className="text-xs text-muted-foreground text-center">
        {intensityScale.levels.find(l => 
          currentIntensity >= l.value && 
          currentIntensity < (intensityScale.levels.find(nl => nl.value > l.value)?.value ?? Infinity)
        )?.description ?? 'No shaking'}
      </div>
    </div>
  )
}
