'use client'

import { useSimulatorStore } from '@/lib/earthquake-store'
import { getIntensityColor, getIntensityLabel } from '@/lib/intensity-scales'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Radio } from 'lucide-react'
import type { SensorDisplayMode } from '@/lib/earthquake-types'

export function SensorReadingsTable() {
  const {
    sensors,
    sensorReadings,
    sensorDisplayMode,
    setSensorDisplayMode,
    intensityScale,
  } = useSimulatorStore()

  const formatValue = (value: number, mode: SensorDisplayMode) => {
    switch (mode) {
      case 'intensity':
        return value > 0 ? value.toFixed(1) : '-'
      case 'pga':
        return value > 0 ? `${value.toFixed(1)}` : '-'
      case 'pgv':
        return value > 0 ? `${value.toFixed(2)}` : '-'
      default:
        return value.toFixed(1)
    }
  }

  const getUnit = (mode: SensorDisplayMode) => {
    switch (mode) {
      case 'pga':
        return 'gal'
      case 'pgv':
        return 'kine'
      default:
        return ''
    }
  }

  // Sort sensors by current intensity (highest first)
  const sortedSensors = [...sensors].sort((a, b) => {
    const readingA = sensorReadings.get(a.id)
    const readingB = sensorReadings.get(b.id)
    return (readingB?.intensity ?? 0) - (readingA?.intensity ?? 0)
  })

  return (
    <Card className="bg-sidebar-accent border-sidebar-border flex-1 min-h-0">
      <CardHeader className="py-2 px-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xs font-medium text-sidebar-foreground/70 uppercase tracking-wide flex items-center gap-2">
            <Radio className="w-3 h-3" />
            Sensors ({sensors.length})
          </CardTitle>
          <Select
            value={sensorDisplayMode}
            onValueChange={(value) => setSensorDisplayMode(value as SensorDisplayMode)}
          >
            <SelectTrigger className="h-6 w-20 text-[10px] bg-sidebar border-sidebar-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="intensity">Int.</SelectItem>
              <SelectItem value="pga">PGA</SelectItem>
              <SelectItem value="pgv">PGV</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="py-1 px-3 overflow-y-auto max-h-48">
        {sensors.length === 0 ? (
          <div className="text-xs text-sidebar-foreground/50 text-center py-4">
            No sensors added
          </div>
        ) : (
          <div className="space-y-1">
            {sortedSensors.map((sensor) => {
              const reading = sensorReadings.get(sensor.id)
              const intensity = reading?.intensity ?? 0
              const displayValue = sensorDisplayMode === 'intensity' 
                ? intensity 
                : sensorDisplayMode === 'pga' 
                  ? (reading?.pga ?? 0)
                  : (reading?.pgv ?? 0)
              const color = getIntensityColor(intensityScale, intensity)
              
              return (
                <div
                  key={sensor.id}
                  className="flex items-center justify-between py-1 px-2 rounded-md hover:bg-sidebar transition-colors"
                  style={{
                    borderLeft: `3px solid ${intensity > 0 ? color : 'transparent'}`
                  }}
                >
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <div
                      className="w-2 h-2 rounded-full flex-shrink-0"
                      style={{ backgroundColor: reading?.triggered ? color : '#444' }}
                    />
                    <span className="text-xs text-sidebar-foreground truncate">
                      {sensor.name}
                    </span>
                    {sensor.isRealSensor && (
                      <span className="text-[8px] text-blue-400 uppercase">Real</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {sensorDisplayMode === 'intensity' && intensity > 0 && (
                      <span
                        className="w-6 h-5 rounded text-[10px] font-bold flex items-center justify-center"
                        style={{ backgroundColor: color, color: '#000' }}
                      >
                        {getIntensityLabel(intensityScale, intensity)}
                      </span>
                    )}
                    <span className="text-xs font-mono text-sidebar-foreground w-12 text-right">
                      {formatValue(displayValue, sensorDisplayMode)}
                    </span>
                    {getUnit(sensorDisplayMode) && (
                      <span className="text-[9px] text-sidebar-foreground/50 w-8">
                        {getUnit(sensorDisplayMode)}
                      </span>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
