'use client'

import { useSimulatorStore } from '@/lib/earthquake-store'
import { getIntensityLabel, getIntensityColor } from '@/lib/intensity-scales'
import { EarthquakeInfoCard } from './earthquake-info-card'
import { ActiveWarningsList } from './active-warnings-list'
import { SensorReadingsTable } from './sensor-readings-table'
import { WaveStatusDisplay } from './wave-status-display'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function InfoSidebar() {
  const { sidebarCollapsed, toggleSidebar, currentIntensity, intensityScale } = useSimulatorStore()

  const intensityColor = getIntensityColor(intensityScale, currentIntensity)
  const intensityLabel = getIntensityLabel(intensityScale, currentIntensity)

  return (
    <div
      className={cn(
        'relative flex flex-col h-full bg-sidebar border-r border-sidebar-border transition-all duration-300',
        sidebarCollapsed ? 'w-12' : 'w-72'
      )}
    >
      {/* Collapse toggle */}
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleSidebar}
        className="absolute -right-3 top-4 z-10 h-6 w-6 rounded-full border border-sidebar-border bg-sidebar hover:bg-sidebar-accent"
      >
        {sidebarCollapsed ? <ChevronRight className="h-3 w-3" /> : <ChevronLeft className="h-3 w-3" />}
      </Button>

      {sidebarCollapsed ? (
        // Collapsed view - just show intensity
        <div className="flex flex-col items-center gap-4 pt-12">
          <div
            className="w-8 h-8 rounded-md flex items-center justify-center font-bold text-xs"
            style={{ backgroundColor: intensityColor, color: '#000' }}
          >
            {intensityLabel}
          </div>
        </div>
      ) : (
        // Expanded view
        <div className="flex flex-col gap-3 p-3 overflow-y-auto flex-1">
          {/* Current Intensity Display */}
          <div className="flex items-center gap-3 p-3 rounded-lg bg-sidebar-accent">
            <div
              className="w-14 h-14 rounded-lg flex items-center justify-center font-bold text-xl shadow-lg"
              style={{ backgroundColor: intensityColor, color: '#000' }}
            >
              {intensityLabel}
            </div>
            <div className="flex-1">
              <div className="text-xs text-sidebar-foreground/60 uppercase tracking-wide">
                Current Intensity
              </div>
              <div className="text-lg font-semibold text-sidebar-foreground">
                {currentIntensity.toFixed(1)}
              </div>
              <div className="text-xs text-sidebar-foreground/60">
                {intensityScale.name}
              </div>
            </div>
          </div>

          {/* Earthquake Info */}
          <EarthquakeInfoCard />

          {/* Active Warnings */}
          <ActiveWarningsList />

          {/* Wave Status */}
          <WaveStatusDisplay />

          {/* Sensor Readings */}
          <SensorReadingsTable />
        </div>
      )}
    </div>
  )
}
