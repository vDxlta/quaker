'use client'

import { useSimulatorStore } from '@/lib/earthquake-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { MapPin, Gauge, ArrowDown, Clock } from 'lucide-react'

export function EarthquakeInfoCard() {
  const { earthquakeInfo, currentTime } = useSimulatorStore()

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const timeSinceOrigin = currentTime - earthquakeInfo.originTime
  const hasStarted = timeSinceOrigin >= 0

  return (
    <Card className="bg-sidebar-accent border-sidebar-border">
      <CardHeader className="py-2 px-3">
        <CardTitle className="text-xs font-medium text-sidebar-foreground/70 uppercase tracking-wide flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          Earthquake Info
        </CardTitle>
      </CardHeader>
      <CardContent className="py-2 px-3 space-y-2">
        {/* Magnitude */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sidebar-foreground/70">
            <Gauge className="w-3.5 h-3.5" />
            <span className="text-xs">Magnitude</span>
          </div>
          <span className="font-bold text-lg text-sidebar-foreground">
            M{earthquakeInfo.magnitude.toFixed(1)}
          </span>
        </div>

        {/* Depth */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sidebar-foreground/70">
            <ArrowDown className="w-3.5 h-3.5" />
            <span className="text-xs">Depth</span>
          </div>
          <span className="font-semibold text-sidebar-foreground">
            {earthquakeInfo.depth} km
          </span>
        </div>

        {/* Location */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2 text-sidebar-foreground/70">
            <MapPin className="w-3.5 h-3.5" />
            <span className="text-xs">Location</span>
          </div>
          <span className="text-xs text-sidebar-foreground text-right max-w-[120px] truncate">
            {earthquakeInfo.locationName}
          </span>
        </div>

        {/* Coordinates */}
        <div className="text-[10px] text-sidebar-foreground/50 text-right">
          {earthquakeInfo.epicenter.lat.toFixed(3)}°N, {earthquakeInfo.epicenter.lng.toFixed(3)}°E
        </div>

        {/* Time since origin */}
        <div className="flex items-center justify-between pt-1 border-t border-sidebar-border">
          <div className="flex items-center gap-2 text-sidebar-foreground/70">
            <Clock className="w-3.5 h-3.5" />
            <span className="text-xs">Elapsed</span>
          </div>
          <span className={`font-mono text-sm ${hasStarted ? 'text-red-400' : 'text-sidebar-foreground/50'}`}>
            {hasStarted ? `+${formatTime(timeSinceOrigin)}` : `T-${formatTime(Math.abs(timeSinceOrigin))}`}
          </span>
        </div>
      </CardContent>
    </Card>
  )
}
