'use client'

import { useState, useEffect } from 'react'
import { useSimulatorStore } from '@/lib/earthquake-store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { Plus, Trash2 } from 'lucide-react'
import { Soundboard } from './soundboard'
import type {
  EventType,
  TimelineEvent,
  IntensityEvent,
  TextEvent,
  SoundEvent,
  WarningEvent,
  AnnotationEvent,
  SensorEvent,
  LocationEvent,
  SavedSound,
} from '@/lib/earthquake-types'

interface EventPanelProps {
  addingEventType?: EventType | null
  onClose?: () => void
}

const EVENT_TYPE_LABELS: Record<EventType, string> = {
  intensity: 'Intensity',
  text: 'Text Overlay',
  sound: 'Sound Effect',
  warning: 'Warning / Alert',
  annotation: 'Annotation',
  sensor: 'Sensor',
  location: 'Location',
}

export function EventPanel({ addingEventType, onClose }: EventPanelProps) {
  const {
    events,
    selectedEventId,
    selectEvent,
    addEvent,
    updateEvent,
    removeEvent,
    currentTime,
    eventPanelOpen,
    setEventPanelOpen,
    sensors,
    intensityScale,
    savedSounds,
  } = useSimulatorStore()

  const selectedEvent = events.find((e) => e.id === selectedEventId)
  const isAdding = addingEventType != null

  // Panel is open if explicitly adding OR if eventPanelOpen is true AND there's a selected event
  const isOpen = isAdding || (eventPanelOpen && !!selectedEvent)

  // Form state for new events
  const [newForm, setNewForm] = useState<Record<string, any>>({})

  useEffect(() => {
    if (addingEventType) {
      setNewForm({
        startTime: currentTime,
        duration: 5,
      })
    }
  }, [addingEventType, currentTime])

  const handleClose = () => {
    selectEvent(null)
    setEventPanelOpen(false)
    onClose?.()
  }

  const handleAddEvent = () => {
    if (!addingEventType) return

    const base = {
      id: crypto.randomUUID(),
      type: addingEventType,
      startTime: Number(newForm.startTime ?? currentTime),
      duration: Number(newForm.duration ?? 5),
      track: 0,
    }

    let event: TimelineEvent

    switch (addingEventType) {
      case 'intensity':
        event = {
          ...base,
          type: 'intensity',
          intensity: Number(newForm.intensity ?? 4),
          easing: (newForm.easing as IntensityEvent['easing']) ?? 'ease-in-out',
        } as IntensityEvent
        break
      case 'text':
        event = {
          ...base,
          type: 'text',
          text: String(newForm.text ?? 'Text overlay'),
          position: (newForm.position as TextEvent['position']) ?? 'center',
          fontSize: (newForm.fontSize as TextEvent['fontSize']) ?? 'large',
          style: (newForm.style as TextEvent['style']) ?? 'normal',
        } as TextEvent
        break
      case 'sound':
        event = {
          ...base,
          type: 'sound',
          soundType: (newForm.soundType as SoundEvent['soundType']) ?? 'alarm',
          volume: Number(newForm.volume ?? 0.8),
          soundId: newForm.soundId,
          customUrl: newForm.customUrl,
        } as SoundEvent
        break
      case 'warning':
        event = {
          ...base,
          type: 'warning',
          warningType: (newForm.warningType as WarningEvent['warningType']) ?? 'eew',
          severity: (newForm.severity as WarningEvent['severity']) ?? 'warning',
          title: String(newForm.title ?? 'Warning'),
          message: String(newForm.message ?? ''),
        } as WarningEvent
        break
      case 'annotation':
        event = {
          ...base,
          type: 'annotation',
          text: String(newForm.text ?? 'Annotation'),
          position: { lat: 35.6762, lng: 139.6503 },
          showLine: true,
        } as AnnotationEvent
        break
      case 'sensor':
        event = {
          ...base,
          type: 'sensor',
          sensorId: String(newForm.sensorId ?? sensors[0]?.id ?? ''),
          action: (newForm.action as SensorEvent['action']) ?? 'highlight',
        } as SensorEvent
        break
      case 'location':
        event = {
          ...base,
          type: 'location',
          name: String(newForm.name ?? 'Location'),
          position: { lat: 35.6762, lng: 139.6503 },
          markerStyle: (newForm.markerStyle as LocationEvent['markerStyle']) ?? 'pin',
        } as LocationEvent
        break
      default:
        return
    }

    addEvent(event)
    handleClose()
  }

  // ----- Shared field helpers -----
  const field = (label: string, children: React.ReactNode) => (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</Label>
      {children}
    </div>
  )

  const numInput = (
    key: string,
    value: number,
    onChange: (v: number) => void,
    step = 0.1
  ) => (
    <Input
      type="number"
      value={value}
      step={step}
      onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
      className="h-8"
    />
  )

  // ----- Form for new event -----
  const renderNewForm = () => {
    if (!addingEventType) return null

    const set = (key: string, val: any) => setNewForm((p) => ({ ...p, [key]: val }))

    const commonFields = (
      <>
        {field('Start Time (sec)', numInput('st', newForm.startTime ?? currentTime, (v) => set('startTime', v)))}
        {field('Duration (sec)', numInput('dur', newForm.duration ?? 5, (v) => set('duration', v)))}
      </>
    )

    switch (addingEventType) {
      case 'intensity':
        return (
          <>
            {commonFields}
            {field(
              `Intensity: ${(newForm.intensity ?? 4).toFixed(1)}`,
              <Slider
                value={[newForm.intensity ?? 4]}
                min={0}
                max={intensityScale.levels[intensityScale.levels.length - 1].value}
                step={0.1}
                onValueChange={([v]) => set('intensity', v)}
              />
            )}
            {field('Easing',
              <Select value={newForm.easing ?? 'ease-in-out'} onValueChange={(v) => set('easing', v)}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="linear">Linear</SelectItem>
                  <SelectItem value="ease-in">Ease In</SelectItem>
                  <SelectItem value="ease-out">Ease Out</SelectItem>
                  <SelectItem value="ease-in-out">Ease In-Out</SelectItem>
                </SelectContent>
              </Select>
            )}
          </>
        )
      case 'text':
        return (
          <>
            {commonFields}
            {field('Text',
              <Textarea
                value={newForm.text ?? ''}
                onChange={(e) => set('text', e.target.value)}
                rows={3}
                placeholder="Enter text to display..."
              />
            )}
            {field('Position',
              <Select value={newForm.position ?? 'center'} onValueChange={(v) => set('position', v)}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="top">Top</SelectItem>
                  <SelectItem value="center">Center</SelectItem>
                  <SelectItem value="bottom">Bottom</SelectItem>
                </SelectContent>
              </Select>
            )}
            {field('Style',
              <Select value={newForm.style ?? 'normal'} onValueChange={(v) => set('style', v)}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                </SelectContent>
              </Select>
            )}
          </>
        )
      case 'sound':
        return (
          <>
            {commonFields}
            {field('Sound',
              <Select
                value={newForm.soundId || newForm.soundType || 'alarm'}
                onValueChange={(v) => {
                  const saved = savedSounds.find((s) => s.id === v)
                  if (saved) {
                    set('soundType', 'custom')
                    set('soundId', saved.id)
                    set('customUrl', saved.dataUrl)
                  } else {
                    set('soundType', v)
                    set('soundId', undefined)
                    set('customUrl', undefined)
                  }
                }}
              >
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="alarm">Alarm (Built-in)</SelectItem>
                  <SelectItem value="siren">Siren (Built-in)</SelectItem>
                  <SelectItem value="beep">Beep (Built-in)</SelectItem>
                  <SelectItem value="rumble">Rumble (Built-in)</SelectItem>
                  {savedSounds.map((s) => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            {field(
              `Volume: ${Math.round((newForm.volume ?? 0.8) * 100)}%`,
              <Slider
                value={[newForm.volume ?? 0.8]}
                min={0} max={1} step={0.05}
                onValueChange={([v]) => set('volume', v)}
              />
            )}
          </>
        )
      case 'warning':
        return (
          <>
            {commonFields}
            {field('Warning Type',
              <Select value={newForm.warningType ?? 'eew'} onValueChange={(v) => set('warningType', v)}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="eew">Earthquake Early Warning</SelectItem>
                  <SelectItem value="tsunami">Tsunami Warning</SelectItem>
                  <SelectItem value="intensity-alert">Intensity Alert</SelectItem>
                  <SelectItem value="long-period">Long-period Motion</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            )}
            {field('Severity',
              <Select value={newForm.severity ?? 'warning'} onValueChange={(v) => set('severity', v)}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="advisory">Advisory</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="emergency">Emergency</SelectItem>
                </SelectContent>
              </Select>
            )}
            {field('Title',
              <Input
                value={newForm.title ?? ''}
                onChange={(e) => set('title', e.target.value)}
                placeholder="Warning title"
                className="h-8"
              />
            )}
            {field('Message',
              <Textarea
                value={newForm.message ?? ''}
                onChange={(e) => set('message', e.target.value)}
                rows={2}
                placeholder="Warning message..."
              />
            )}
          </>
        )
      case 'sensor':
        return (
          <>
            {commonFields}
            {field('Sensor',
              <Select value={newForm.sensorId ?? sensors[0]?.id ?? ''} onValueChange={(v) => set('sensorId', v)}>
                <SelectTrigger className="h-8"><SelectValue placeholder="Select sensor..." /></SelectTrigger>
                <SelectContent>
                  {sensors.length === 0
                    ? <SelectItem value="" disabled>No sensors added yet</SelectItem>
                    : sensors.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)
                  }
                </SelectContent>
              </Select>
            )}
            {field('Action',
              <Select value={newForm.action ?? 'highlight'} onValueChange={(v) => set('action', v)}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="add">Add Sensor</SelectItem>
                  <SelectItem value="remove">Remove Sensor</SelectItem>
                  <SelectItem value="highlight">Highlight Sensor</SelectItem>
                </SelectContent>
              </Select>
            )}
          </>
        )
      case 'location':
        return (
          <>
            {commonFields}
            {field('Name',
              <Input
                value={newForm.name ?? ''}
                onChange={(e) => set('name', e.target.value)}
                placeholder="Location name"
                className="h-8"
              />
            )}
            {field('Marker Style',
              <Select value={newForm.markerStyle ?? 'pin'} onValueChange={(v) => set('markerStyle', v)}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pin">Pin</SelectItem>
                  <SelectItem value="circle">Circle</SelectItem>
                  <SelectItem value="star">Star</SelectItem>
                </SelectContent>
              </Select>
            )}
          </>
        )
      default:
        return commonFields
    }
  }

  // ----- Editor for existing event -----
  const renderEditor = (ev: TimelineEvent) => {
    const up = (updates: Partial<TimelineEvent>) => updateEvent(ev.id, updates)

    const commonFields = (
      <>
        {field('Start Time (sec)',
          numInput('st', ev.startTime, (v) => up({ startTime: v }))
        )}
        {field('Duration (sec)',
          numInput('dur', ev.duration, (v) => up({ duration: v }))
        )}
      </>
    )

    switch (ev.type) {
      case 'intensity': {
        const e = ev as IntensityEvent
        return (
          <>
            {commonFields}
            {field(`Intensity: ${e.intensity.toFixed(1)}`,
              <Slider
                value={[e.intensity]}
                min={0}
                max={intensityScale.levels[intensityScale.levels.length - 1].value}
                step={0.1}
                onValueChange={([v]) => up({ intensity: v })}
              />
            )}
            {field('Easing',
              <Select value={e.easing} onValueChange={(v) => up({ easing: v as IntensityEvent['easing'] })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="linear">Linear</SelectItem>
                  <SelectItem value="ease-in">Ease In</SelectItem>
                  <SelectItem value="ease-out">Ease Out</SelectItem>
                  <SelectItem value="ease-in-out">Ease In-Out</SelectItem>
                </SelectContent>
              </Select>
            )}
          </>
        )
      }
      case 'text': {
        const e = ev as TextEvent
        return (
          <>
            {commonFields}
            {field('Text',
              <Textarea value={e.text} onChange={(ev2) => up({ text: ev2.target.value })} rows={3} />
            )}
            {field('Position',
              <Select value={e.position} onValueChange={(v) => up({ position: v as TextEvent['position'] })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="top">Top</SelectItem>
                  <SelectItem value="center">Center</SelectItem>
                  <SelectItem value="bottom">Bottom</SelectItem>
                </SelectContent>
              </Select>
            )}
            {field('Font Size',
              <Select value={e.fontSize} onValueChange={(v) => up({ fontSize: v as TextEvent['fontSize'] })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="small">Small</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="large">Large</SelectItem>
                  <SelectItem value="xlarge">Extra Large</SelectItem>
                </SelectContent>
              </Select>
            )}
            {field('Style',
              <Select value={e.style} onValueChange={(v) => up({ style: v as TextEvent['style'] })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                </SelectContent>
              </Select>
            )}
          </>
        )
      }
      case 'sound': {
        const e = ev as SoundEvent
        return (
          <>
            {commonFields}
            {field('Sound',
              <Select
                value={e.soundId || e.soundType}
                onValueChange={(v) => {
                  const saved = savedSounds.find((s) => s.id === v)
                  if (saved) {
                    up({ soundType: 'custom', soundId: saved.id, customUrl: saved.dataUrl })
                  } else {
                    up({ soundType: v as SoundEvent['soundType'], soundId: undefined, customUrl: undefined })
                  }
                }}
              >
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="alarm">Alarm (Built-in)</SelectItem>
                  <SelectItem value="siren">Siren (Built-in)</SelectItem>
                  <SelectItem value="beep">Beep (Built-in)</SelectItem>
                  <SelectItem value="rumble">Rumble (Built-in)</SelectItem>
                  {savedSounds.map((s) => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            {field(`Volume: ${Math.round(e.volume * 100)}%`,
              <Slider
                value={[e.volume]}
                min={0} max={1} step={0.05}
                onValueChange={([v]) => up({ volume: v })}
              />
            )}
            <div className="pt-1">
              <Soundboard
                onSelectSound={(sound) => {
                  if (sound.dataUrl) {
                    up({ soundType: 'custom', soundId: sound.id, customUrl: sound.dataUrl })
                  } else {
                    up({ soundType: sound.name.toLowerCase() as SoundEvent['soundType'], soundId: undefined, customUrl: undefined })
                  }
                }}
              />
            </div>
          </>
        )
      }
      case 'warning': {
        const e = ev as WarningEvent
        return (
          <>
            {commonFields}
            {field('Warning Type',
              <Select value={e.warningType} onValueChange={(v) => up({ warningType: v as WarningEvent['warningType'] })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="eew">Earthquake Early Warning</SelectItem>
                  <SelectItem value="tsunami">Tsunami Warning</SelectItem>
                  <SelectItem value="intensity-alert">Intensity Alert</SelectItem>
                  <SelectItem value="long-period">Long-period Motion</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            )}
            {field('Severity',
              <Select value={e.severity} onValueChange={(v) => up({ severity: v as WarningEvent['severity'] })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="advisory">Advisory</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="emergency">Emergency</SelectItem>
                </SelectContent>
              </Select>
            )}
            {field('Title',
              <Input value={e.title} onChange={(ev2) => up({ title: ev2.target.value })} className="h-8" />
            )}
            {field('Message',
              <Textarea value={e.message} onChange={(ev2) => up({ message: ev2.target.value })} rows={3} />
            )}
          </>
        )
      }
      case 'sensor': {
        const e = ev as SensorEvent
        return (
          <>
            {commonFields}
            {field('Sensor',
              <Select value={e.sensorId} onValueChange={(v) => up({ sensorId: v })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {sensors.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
            {field('Action',
              <Select value={e.action} onValueChange={(v) => up({ action: v as SensorEvent['action'] })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="add">Add</SelectItem>
                  <SelectItem value="remove">Remove</SelectItem>
                  <SelectItem value="highlight">Highlight</SelectItem>
                </SelectContent>
              </Select>
            )}
          </>
        )
      }
      case 'location': {
        const e = ev as LocationEvent
        return (
          <>
            {commonFields}
            {field('Name',
              <Input value={e.name} onChange={(ev2) => up({ name: ev2.target.value })} className="h-8" />
            )}
            {field('Marker Style',
              <Select value={e.markerStyle} onValueChange={(v) => up({ markerStyle: v as LocationEvent['markerStyle'] })}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pin">Pin</SelectItem>
                  <SelectItem value="circle">Circle</SelectItem>
                  <SelectItem value="star">Star</SelectItem>
                </SelectContent>
              </Select>
            )}
          </>
        )
      }
      default:
        return commonFields
    }
  }

  return (
    <Sheet
      open={isOpen}
      onOpenChange={(open) => { if (!open) handleClose() }}
    >
      <SheetContent side="right" className="w-80 flex flex-col p-0">
        <SheetHeader className="px-4 py-3 border-b border-border">
          <SheetTitle className="text-sm">
            {isAdding
              ? `Add ${EVENT_TYPE_LABELS[addingEventType!] ?? addingEventType}`
              : selectedEvent
              ? `Edit ${EVENT_TYPE_LABELS[selectedEvent.type] ?? selectedEvent.type}`
              : 'Event Editor'}
          </SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-4 py-4">
          {isAdding ? (
            <div className="space-y-4">
              {renderNewForm()}
            </div>
          ) : selectedEvent ? (
            <div className="space-y-4">
              {renderEditor(selectedEvent)}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">
              Select an event from the timeline to edit it, or click the{' '}
              <span className="font-mono">+</span> button on a track to add a new event.
            </p>
          )}
        </div>

        {(isAdding || selectedEvent) && (
          <div className="px-4 py-3 border-t border-border flex gap-2">
            {isAdding ? (
              <>
                <Button variant="outline" onClick={handleClose} className="flex-1 h-8">
                  Cancel
                </Button>
                <Button onClick={handleAddEvent} className="flex-1 h-8">
                  <Plus className="w-3.5 h-3.5 mr-1.5" />
                  Add Event
                </Button>
              </>
            ) : (
              <>
                <Button
                  variant="destructive"
                  size="sm"
                  className="h-8"
                  onClick={() => {
                    if (selectedEvent) {
                      removeEvent(selectedEvent.id)
                      handleClose()
                    }
                  }}
                >
                  <Trash2 className="w-3.5 h-3.5 mr-1.5" />
                  Delete
                </Button>
                <Button variant="outline" onClick={handleClose} className="flex-1 h-8">
                  Close
                </Button>
              </>
            )}
          </div>
        )}
      </SheetContent>
    </Sheet>
  )
}
