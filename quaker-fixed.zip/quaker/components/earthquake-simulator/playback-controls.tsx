'use client'

import { useSimulatorStore } from '@/lib/earthquake-store'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
} from 'lucide-react'
import { useState } from 'react'

export function PlaybackControls() {
  const {
    isPlaying,
    currentTime,
    duration,
    playbackSpeed,
    play,
    pause,
    stop,
    seek,
    setPlaybackSpeed,
    isRecording,
  } = useSimulatorStore()

  const [isMuted, setIsMuted] = useState(false)

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    const ms = Math.floor((seconds % 1) * 100)
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`
  }

  const handleSeek = (value: number[]) => {
    seek(value[0])
  }

  const skipBackward = () => {
    seek(Math.max(0, currentTime - 5))
  }

  const skipForward = () => {
    seek(Math.min(duration, currentTime + 5))
  }

  return (
    <div className="flex items-center gap-4 px-4 py-2 bg-card border-t border-border">
      {/* Transport controls */}
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          onClick={stop}
          disabled={isRecording}
          className="h-8 w-8"
        >
          <Square className="h-4 w-4" />
        </Button>
        
        <Button
          variant="ghost"
          size="icon"
          onClick={skipBackward}
          disabled={isRecording}
          className="h-8 w-8"
        >
          <SkipBack className="h-4 w-4" />
        </Button>
        
        <Button
          variant="default"
          size="icon"
          onClick={isPlaying ? pause : play}
          disabled={isRecording}
          className="h-10 w-10"
        >
          {isPlaying ? (
            <Pause className="h-5 w-5" />
          ) : (
            <Play className="h-5 w-5 ml-0.5" />
          )}
        </Button>
        
        <Button
          variant="ghost"
          size="icon"
          onClick={skipForward}
          disabled={isRecording}
          className="h-8 w-8"
        >
          <SkipForward className="h-4 w-4" />
        </Button>
      </div>

      {/* Time display */}
      <div className="flex items-center gap-2 min-w-[140px]">
        <span className="font-mono text-sm text-foreground">
          {formatTime(currentTime)}
        </span>
        <span className="text-muted-foreground">/</span>
        <span className="font-mono text-sm text-muted-foreground">
          {formatTime(duration)}
        </span>
      </div>

      {/* Progress slider */}
      <div className="flex-1 px-2">
        <Slider
          value={[currentTime]}
          min={0}
          max={duration}
          step={0.1}
          onValueChange={handleSeek}
          disabled={isRecording}
          className="w-full"
        />
      </div>

      {/* Speed control */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground">Speed:</span>
        <Select
          value={playbackSpeed.toString()}
          onValueChange={(value) => setPlaybackSpeed(parseFloat(value))}
          disabled={isRecording}
        >
          <SelectTrigger className="h-8 w-20">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="0.25">0.25x</SelectItem>
            <SelectItem value="0.5">0.5x</SelectItem>
            <SelectItem value="1">1x</SelectItem>
            <SelectItem value="1.5">1.5x</SelectItem>
            <SelectItem value="2">2x</SelectItem>
            <SelectItem value="4">4x</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Volume */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsMuted(!isMuted)}
        className="h-8 w-8"
      >
        {isMuted ? (
          <VolumeX className="h-4 w-4" />
        ) : (
          <Volume2 className="h-4 w-4" />
        )}
      </Button>
    </div>
  )
}
