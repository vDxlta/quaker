'use client'

import { useRef, useCallback, useState, useEffect } from 'react'
import { useSimulatorStore } from '@/lib/earthquake-store'
import { getIntensityColor } from '@/lib/intensity-scales'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import {
  Plus,
  ZoomIn,
  ZoomOut,
  Trash2,
  ChevronDown,
  ChevronRight,
  GripVertical,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { TimelineEvent, EventType } from '@/lib/earthquake-types'

const TRACK_HEIGHT = 36
const HEADER_HEIGHT = 32
const TRACK_LABELS: Record<string, string> = {
  intensity: 'Intensity',
  text: 'Text / Overlays',
  sound: 'Sound Effects',
  warning: 'Warnings / Alerts',
  sensor: 'Sensors',
  annotation: 'Annotations',
  location: 'Locations',
}

const TRACK_COLORS: Record<string, string> = {
  intensity: '#ff6b6b',
  text: '#4ecdc4',
  sound: '#45b7d1',
  warning: '#f9ca24',
  sensor: '#6c5ce7',
  annotation: '#a29bfe',
  location: '#fd79a8',
}

interface TimelineEditorProps {
  className?: string
  onAddEvent?: (type: EventType) => void
}

export function TimelineEditor({ className, onAddEvent }: TimelineEditorProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [collapsedTracks, setCollapsedTracks] = useState<Set<string>>(new Set())
  
  // Drag state for events
  const [draggingEvent, setDraggingEvent] = useState<{
    eventId: string
    startX: number
    originalStartTime: number
    originalDuration: number
    dragType: 'move' | 'resize-start' | 'resize-end'
  } | null>(null)
  
  const {
    events,
    currentTime,
    duration,
    timelineZoom,
    setTimelineZoom,
    selectedEventId,
    selectEvent,
    removeEvent,
    updateEvent,
    seek,
    intensityScale,
    setEventPanelOpen,
  } = useSimulatorStore()

  // Calculate pixels per second based on zoom
  const pixelsPerSecond = 30 * timelineZoom
  const timelineWidth = duration * pixelsPerSecond

  // Get events grouped by track
  const trackTypes: EventType[] = ['intensity', 'text', 'sound', 'warning', 'sensor', 'annotation', 'location']
  const eventsByTrack = trackTypes.reduce((acc, type) => {
    acc[type] = events.filter(e => e.type === type)
    return acc
  }, {} as Record<EventType, TimelineEvent[]>)

  const toggleTrack = (track: string) => {
    setCollapsedTracks(prev => {
      const next = new Set(prev)
      if (next.has(track)) {
        next.delete(track)
      } else {
        next.add(track)
      }
      return next
    })
  }

  const handleTimelineClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    // Only seek if clicking directly on the track background, not on an event block
    const target = e.target as HTMLElement
    if (target.closest('[data-event-block]')) return
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left + (containerRef.current?.scrollLeft ?? 0)
    const time = x / pixelsPerSecond
    seek(Math.max(0, Math.min(duration, time)))
  }, [pixelsPerSecond, seek, duration])

  const handleEventClick = (e: React.MouseEvent, eventId: string) => {
    e.stopPropagation()
    selectEvent(selectedEventId === eventId ? null : eventId)
    setEventPanelOpen(true)
  }

  const handleDeleteEvent = (e: React.MouseEvent, eventId: string) => {
    e.stopPropagation()
    removeEvent(eventId)
  }

  // Event dragging handlers
  const handleEventDragStart = (e: React.MouseEvent, event: TimelineEvent, dragType: 'move' | 'resize-start' | 'resize-end') => {
    e.stopPropagation()
    e.preventDefault()
    setDraggingEvent({
      eventId: event.id,
      startX: e.clientX,
      originalStartTime: event.startTime,
      originalDuration: event.duration,
      dragType
    })
    selectEvent(event.id)
  }

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!draggingEvent) return
    
    const deltaX = e.clientX - draggingEvent.startX
    const deltaTime = deltaX / pixelsPerSecond
    
    if (draggingEvent.dragType === 'move') {
      const newStartTime = Math.max(0, Math.min(duration - draggingEvent.originalDuration, draggingEvent.originalStartTime + deltaTime))
      updateEvent(draggingEvent.eventId, { startTime: newStartTime })
    } else if (draggingEvent.dragType === 'resize-end') {
      const newDuration = Math.max(0.5, draggingEvent.originalDuration + deltaTime)
      updateEvent(draggingEvent.eventId, { duration: newDuration })
    } else if (draggingEvent.dragType === 'resize-start') {
      const newStartTime = Math.max(0, draggingEvent.originalStartTime + deltaTime)
      const newDuration = Math.max(0.5, draggingEvent.originalDuration - deltaTime)
      if (newStartTime >= 0 && newDuration >= 0.5) {
        updateEvent(draggingEvent.eventId, { startTime: newStartTime, duration: newDuration })
      }
    }
  }, [draggingEvent, pixelsPerSecond, duration, updateEvent])

  const handleMouseUp = useCallback(() => {
    setDraggingEvent(null)
  }, [])

  // Attach global mouse listeners for dragging
  useEffect(() => {
    if (draggingEvent) {
      window.addEventListener('mousemove', handleMouseMove)
      window.addEventListener('mouseup', handleMouseUp)
      return () => {
        window.removeEventListener('mousemove', handleMouseMove)
        window.removeEventListener('mouseup', handleMouseUp)
      }
    }
  }, [draggingEvent, handleMouseMove, handleMouseUp])

  // Format time for ruler
  const formatRulerTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  // Generate ruler markers
  const rulerMarkers = []
  const majorInterval = timelineZoom < 0.5 ? 30 : timelineZoom < 1 ? 10 : 5
  const minorInterval = majorInterval / 5
  
  for (let t = 0; t <= duration; t += minorInterval) {
    const isMajor = t % majorInterval === 0
    rulerMarkers.push({ time: t, isMajor })
  }

  // Calculate total tracks height
  const visibleTracks = trackTypes.filter(t => !collapsedTracks.has(t))
  const totalHeight = visibleTracks.length * TRACK_HEIGHT + HEADER_HEIGHT + 40

  return (
    <div className={cn('flex flex-col bg-card border-t border-border', className)}>
      {/* Timeline header with zoom controls */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-muted/30">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-foreground">Timeline</span>
          <span className="text-xs text-muted-foreground">
            ({events.length} events)
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTimelineZoom(Math.max(0.25, timelineZoom - 0.25))}
            className="h-7 w-7"
          >
            <ZoomOut className="h-3.5 w-3.5" />
          </Button>
          <Slider
            value={[timelineZoom]}
            min={0.25}
            max={4}
            step={0.25}
            onValueChange={([value]) => setTimelineZoom(value)}
            className="w-24"
          />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTimelineZoom(Math.min(4, timelineZoom + 0.25))}
            className="h-7 w-7"
          >
            <ZoomIn className="h-3.5 w-3.5" />
          </Button>
          <span className="text-xs text-muted-foreground w-12">
            {timelineZoom.toFixed(2)}x
          </span>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Track labels (left side) */}
        <div className="flex-shrink-0 w-32 border-r border-border bg-muted/20">
          {/* Ruler header space */}
          <div className="h-8 border-b border-border" />
          
          {/* Track labels */}
          {trackTypes.map((type) => {
            const isCollapsed = collapsedTracks.has(type)
            const trackEvents = eventsByTrack[type]
            
            return (
              <div
                key={type}
                className={cn(
                  'flex items-center gap-1 px-2 border-b border-border cursor-pointer hover:bg-muted/50 transition-colors',
                  isCollapsed ? 'h-6' : 'h-[36px]'
                )}
                onClick={() => toggleTrack(type)}
              >
                {isCollapsed ? (
                  <ChevronRight className="h-3 w-3 text-muted-foreground" />
                ) : (
                  <ChevronDown className="h-3 w-3 text-muted-foreground" />
                )}
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: TRACK_COLORS[type] }}
                />
                <span className="text-xs text-foreground truncate flex-1">
                  {TRACK_LABELS[type]}
                </span>
                {!isCollapsed && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation()
                      onAddEvent?.(type)
                    }}
                    className="h-5 w-5"
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                )}
                {trackEvents.length > 0 && (
                  <span className="text-[10px] text-muted-foreground">
                    {trackEvents.length}
                  </span>
                )}
              </div>
            )
          })}
        </div>

        {/* Timeline tracks (scrollable) */}
        <div
          ref={containerRef}
          className="flex-1 overflow-x-auto overflow-y-hidden"
          onClick={handleTimelineClick}
        >
          <div
            className="relative"
            style={{ width: timelineWidth, minHeight: totalHeight }}
          >
            {/* Time ruler */}
            <div className="sticky top-0 h-8 bg-muted/50 border-b border-border z-10">
              {rulerMarkers.map(({ time, isMajor }, i) => (
                <div
                  key={i}
                  className="absolute top-0"
                  style={{ left: time * pixelsPerSecond }}
                >
                  <div
                    className={cn(
                      'w-px bg-border',
                      isMajor ? 'h-5' : 'h-2'
                    )}
                  />
                  {isMajor && (
                    <span className="absolute top-5 left-1 text-[10px] text-muted-foreground whitespace-nowrap">
                      {formatRulerTime(time)}
                    </span>
                  )}
                </div>
              ))}
            </div>

            {/* Tracks */}
            <div className="relative" style={{ top: HEADER_HEIGHT }}>
              {trackTypes.map((type, trackIndex) => {
                const isCollapsed = collapsedTracks.has(type)
                if (isCollapsed) return null
                
                const trackEvents = eventsByTrack[type]
                const trackTop = visibleTracks.indexOf(type) * TRACK_HEIGHT
                
                return (
                  <div
                    key={type}
                    className="absolute left-0 right-0 border-b border-border/50"
                    style={{
                      top: trackTop,
                      height: TRACK_HEIGHT,
                    }}
                  >
                    {/* Track background */}
                    <div
                      className="absolute inset-0 opacity-5"
                      style={{ backgroundColor: TRACK_COLORS[type] }}
                    />
                    
                    {/* Events on this track */}
                    {trackEvents.map((event) => {
                      const left = event.startTime * pixelsPerSecond
                      const width = Math.max(20, event.duration * pixelsPerSecond)
                      const isSelected = selectedEventId === event.id
                      
                      // Get event-specific display
                      let eventLabel = ''
                      let eventColor = TRACK_COLORS[type]
                      
                      if (event.type === 'intensity') {
                        eventLabel = `Int: ${event.intensity}`
                        eventColor = getIntensityColor(intensityScale, event.intensity)
                      } else if (event.type === 'text') {
                        eventLabel = event.text.substring(0, 15) + (event.text.length > 15 ? '...' : '')
                      } else if (event.type === 'warning') {
                        eventLabel = event.title
                      } else if (event.type === 'sound') {
                        eventLabel = event.soundType
                      } else if (event.type === 'sensor') {
                        eventLabel = event.action
                      } else if (event.type === 'annotation') {
                        eventLabel = event.text.substring(0, 15)
                      } else if (event.type === 'location') {
                        eventLabel = event.name
                      }
                      
                      return (
                        <div
                          key={event.id}
                          data-event-block="true"
                          className={cn(
                            'absolute top-1 bottom-1 rounded cursor-grab transition-shadow group',
                            'flex items-center overflow-hidden',
                            isSelected && 'ring-2 ring-primary ring-offset-1 ring-offset-background',
                            draggingEvent?.eventId === event.id && 'cursor-grabbing opacity-75 shadow-lg'
                          )}
                          style={{
                            left,
                            width,
                            backgroundColor: eventColor,
                            color: '#000',
                          }}
                          onClick={(e) => handleEventClick(e, event.id)}
                          onMouseDown={(e) => handleEventDragStart(e, event, 'move')}
                        >
                          {/* Left resize handle */}
                          <div
                            className="absolute left-0 top-0 bottom-0 w-2 cursor-ew-resize hover:bg-black/20 transition-colors"
                            onMouseDown={(e) => handleEventDragStart(e, event, 'resize-start')}
                          />
                          
                          {/* Event content */}
                          <div className="flex-1 flex items-center px-2 min-w-0">
                            <GripVertical className="h-3 w-3 mr-1 opacity-40 flex-shrink-0" />
                            <span className="truncate text-xs font-medium">{eventLabel}</span>
                          </div>
                          
                          {/* Delete button */}
                          {isSelected && (
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={(e) => handleDeleteEvent(e, event.id)}
                              className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 mr-1"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                          
                          {/* Right resize handle */}
                          <div
                            className="absolute right-0 top-0 bottom-0 w-2 cursor-ew-resize hover:bg-black/20 transition-colors"
                            onMouseDown={(e) => handleEventDragStart(e, event, 'resize-end')}
                          />
                        </div>
                      )
                    })}
                  </div>
                )
              })}
            </div>

            {/* Playhead */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-primary z-20 pointer-events-none"
              style={{ left: currentTime * pixelsPerSecond }}
            >
              {/* Playhead head */}
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-primary rotate-45" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
