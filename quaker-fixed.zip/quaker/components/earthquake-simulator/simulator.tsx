'use client'

import { useRef, useEffect, useCallback, useState } from 'react'
import { useSimulatorStore } from '@/lib/earthquake-store'
import { updateSensorReadings, calculateWaveRadius } from '@/lib/wave-calculations'
import { MapView } from './map-view'
import { InfoSidebar } from './info-sidebar'
import { IntensityGauge } from './intensity-gauge'
import { TimelineEditor } from './timeline-editor'
import { PlaybackControls } from './playback-controls'
import { EventPanel } from './event-panel'
import { SettingsPanel } from './settings-panel'
import { ExportControls } from './export-controls'
import { TextOverlay } from './text-overlay'
import { WarningAlert } from './warning-alert'
import { Soundboard } from './soundboard'
import { Button } from '@/components/ui/button'
import { Save, FolderOpen, RotateCcw } from 'lucide-react'
import type { EventType, IntensityEvent } from '@/lib/earthquake-types'

export function EarthquakeSimulator() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [addingEventType, setAddingEventType] = useState<EventType | null>(null)

  const {
    isPlaying,
    currentTime,
    duration,
    playbackSpeed,
    seek,
    events,
    sensors,
    epicenter,
    earthquakeInfo,
    pWaveSpeed,
    sWaveSpeed,
    setPWaveRadius,
    setSWaveRadius,
    sensorReadings,
    updateSensorReadings: setSensorReadings,
    setCurrentIntensity,
    exportScenario,
    loadScenario,
    resetScenario,
  } = useSimulatorStore()

  // Playback loop
  useEffect(() => {
    if (!isPlaying) return

    let lastTime = performance.now()
    let animationFrame: number

    const tick = (now: number) => {
      const delta = (now - lastTime) / 1000 * playbackSpeed
      lastTime = now

      const newTime = currentTime + delta
      
      if (newTime >= duration) {
        seek(duration)
        useSimulatorStore.getState().pause()
      } else {
        seek(newTime)
      }

      animationFrame = requestAnimationFrame(tick)
    }

    animationFrame = requestAnimationFrame(tick)

    return () => cancelAnimationFrame(animationFrame)
  }, [isPlaying, currentTime, duration, playbackSpeed, seek])

  // Update wave propagation and sensor readings
  useEffect(() => {
    const timeSinceOrigin = currentTime - earthquakeInfo.originTime
    
    if (timeSinceOrigin < 0) {
      setPWaveRadius(0)
      setSWaveRadius(0)
      return
    }

    const pRadius = calculateWaveRadius(timeSinceOrigin, pWaveSpeed)
    const sRadius = calculateWaveRadius(timeSinceOrigin, sWaveSpeed)
    
    setPWaveRadius(pRadius)
    setSWaveRadius(sRadius)

    // Update sensor readings
    const newReadings = updateSensorReadings(
      sensors,
      epicenter,
      currentTime,
      earthquakeInfo.originTime,
      pWaveSpeed,
      sWaveSpeed,
      getCurrentIntensity(),
      earthquakeInfo.depth,
      sensorReadings
    )
    setSensorReadings(newReadings)
  }, [currentTime, earthquakeInfo, pWaveSpeed, sWaveSpeed, sensors, epicenter])

  // Get current intensity from timeline events
  // Important: Intensity holds its value until the next event changes it
  const getCurrentIntensity = useCallback(() => {
    const intensityEvents = events
      .filter((e): e is IntensityEvent => e.type === 'intensity')
      .sort((a, b) => a.startTime - b.startTime)

    if (intensityEvents.length === 0) return 0

    // Find all events that have started before or at current time
    const startedEvents = intensityEvents.filter(e => currentTime >= e.startTime)
    
    if (startedEvents.length === 0) return 0

    // Get the most recent event that started
    const lastStartedEvent = startedEvents[startedEvents.length - 1]
    
    // Check if we're within this event's duration (active transition)
    if (currentTime < lastStartedEvent.startTime + lastStartedEvent.duration) {
      // We're in the transition period - apply easing
      const progress = (currentTime - lastStartedEvent.startTime) / lastStartedEvent.duration
      const easedProgress = applyEasing(Math.min(1, progress), lastStartedEvent.easing)
      
      // Find the previous intensity value to transition from
      const eventIndex = intensityEvents.indexOf(lastStartedEvent)
      const prevIntensity = eventIndex > 0 
        ? intensityEvents[eventIndex - 1].intensity 
        : 0
      
      // Interpolate between previous and current intensity
      return prevIntensity + (lastStartedEvent.intensity - prevIntensity) * easedProgress
    } else {
      // We're past the transition - hold at the target intensity
      return lastStartedEvent.intensity
    }
  }, [events, currentTime])

  // Update current intensity
  useEffect(() => {
    const intensity = getCurrentIntensity()
    setCurrentIntensity(intensity)
  }, [getCurrentIntensity, setCurrentIntensity])

  const handleAddEvent = (type: EventType) => {
    setAddingEventType(type)
  }

  const handleExportScenario = () => {
    const scenario = exportScenario()
    const json = JSON.stringify(scenario, null, 2)
    const blob = new Blob([json], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `earthquake-scenario-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleLoadScenario = () => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = '.json'
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (!file) return
      
      const text = await file.text()
      try {
        const scenario = JSON.parse(text)
        loadScenario(scenario)
      } catch (error) {
        console.error('Failed to load scenario:', error)
      }
    }
    input.click()
  }

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-2 border-b border-border bg-card">
        <div className="flex items-center gap-2">
          <h1 className="text-lg font-bold text-foreground">Earthquake Simulator</h1>
          <span className="text-xs text-muted-foreground px-2 py-0.5 bg-muted rounded">v1.0</span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={handleLoadScenario}>
            <FolderOpen className="w-4 h-4 mr-2" />
            Load
          </Button>
          <Button variant="ghost" size="sm" onClick={handleExportScenario}>
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
          <Button variant="ghost" size="sm" onClick={resetScenario}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          <Soundboard />
          <ExportControls canvasRef={canvasRef} />
          <SettingsPanel />
        </div>
      </header>

      {/* Main content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left sidebar - Info panel */}
        <InfoSidebar />

        {/* Center - Map visualization */}
        <div className="flex-1 relative overflow-hidden">
          <MapView />
          
          {/* Overlays */}
          <TextOverlay />
          <WarningAlert />
          
          {/* Hidden canvas for export - mirrors the map view */}
          <canvas
            ref={canvasRef}
            className="hidden"
            width={1920}
            height={1080}
          />
        </div>

        {/* Right sidebar - Intensity gauge */}
        <div className="w-40 border-l border-border bg-card flex flex-col">
          <IntensityGauge className="flex-1" />
        </div>
      </div>

      {/* Playback controls */}
      <PlaybackControls />

      {/* Timeline */}
      <TimelineEditor 
        className="h-64" 
        onAddEvent={handleAddEvent}
      />

      {/* Event editing panel */}
      <EventPanel 
        addingEventType={addingEventType}
        onClose={() => setAddingEventType(null)}
      />
    </div>
  )
}

// Easing functions
function applyEasing(t: number, easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out'): number {
  switch (easing) {
    case 'linear':
      return t
    case 'ease-in':
      return t * t
    case 'ease-out':
      return t * (2 - t)
    case 'ease-in-out':
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t
    default:
      return t
  }
}
