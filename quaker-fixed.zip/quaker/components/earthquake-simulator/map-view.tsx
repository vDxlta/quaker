'use client'

import { useRef, useEffect, useCallback, useState } from 'react'
import { useSimulatorStore } from '@/lib/earthquake-store'
import { interpolateIntensityColor, getIntensityColor } from '@/lib/intensity-scales'
import { calculateDistance } from '@/lib/wave-calculations'
import { Button } from '@/components/ui/button'
import { ZoomIn, ZoomOut, Crosshair, Move } from 'lucide-react'
import type { Position, Sensor } from '@/lib/earthquake-types'

interface MapViewProps {
  className?: string
}

// Convert lat/lng to canvas coordinates
function latLngToCanvas(
  position: Position,
  center: Position,
  zoom: number,
  canvasWidth: number,
  canvasHeight: number
): { x: number; y: number } {
  const scale = Math.pow(2, zoom) * 40 // pixels per degree
  const x = canvasWidth / 2 + (position.lng - center.lng) * scale
  const y = canvasHeight / 2 - (position.lat - center.lat) * scale
  return { x, y }
}

// Convert distance in km to pixels
function kmToPixels(km: number, zoom: number): number {
  const scale = Math.pow(2, zoom) * 40
  // Approximate: 1 degree ≈ 111 km at equator
  return (km / 111) * scale
}

export function MapView({ className }: MapViewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  
  // Drag state
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState<{ x: number; y: number; centerLat: number; centerLng: number } | null>(null)
  
  const {
    epicenter,
    mapZoom,
    mapCenter,
    setMapZoom,
    setMapCenter,
    sensors,
    sensorReadings,
    pWaveRadius,
    sWaveRadius,
    showPWave,
    showSWave,
    intensityScale,
    currentIntensity,
    currentTime,
    earthquakeInfo,
    activeWarnings,
  } = useSimulatorStore()

  // Handle mouse wheel zoom
  const handleWheel = useCallback((e: WheelEvent) => {
    e.preventDefault()
    const delta = e.deltaY > 0 ? -0.5 : 0.5
    const newZoom = Math.max(1, Math.min(15, mapZoom + delta))
    setMapZoom(newZoom)
  }, [mapZoom, setMapZoom])

  // Handle mouse drag to pan
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    setIsDragging(true)
    setDragStart({
      x: e.clientX,
      y: e.clientY,
      centerLat: mapCenter.lat,
      centerLng: mapCenter.lng
    })
  }, [mapCenter])

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging || !dragStart) return
    
    const scale = Math.pow(2, mapZoom) * 40
    const dx = e.clientX - dragStart.x
    const dy = e.clientY - dragStart.y
    
    const newLng = dragStart.centerLng - dx / scale
    const newLat = dragStart.centerLat + dy / scale
    
    setMapCenter({ lat: newLat, lng: newLng })
  }, [isDragging, dragStart, mapZoom, setMapCenter])

  const handleMouseUp = useCallback(() => {
    setIsDragging(false)
    setDragStart(null)
  }, [])

  // Center on epicenter
  const centerOnEpicenter = useCallback(() => {
    setMapCenter(epicenter)
  }, [epicenter, setMapCenter])

  // Attach wheel listener
  useEffect(() => {
    const container = containerRef.current
    if (!container) return
    
    container.addEventListener('wheel', handleWheel, { passive: false })
    return () => container.removeEventListener('wheel', handleWheel)
  }, [handleWheel])

  const drawMap = useCallback(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Set canvas size to match container
    const rect = container.getBoundingClientRect()
    const dpr = window.devicePixelRatio || 1
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    canvas.style.width = `${rect.width}px`
    canvas.style.height = `${rect.height}px`
    ctx.scale(dpr, dpr)

    const width = rect.width
    const height = rect.height

    // Background - dark map style
    ctx.fillStyle = '#0a0a12'
    ctx.fillRect(0, 0, width, height)

    // Draw grid lines
    ctx.strokeStyle = '#1a1a2e'
    ctx.lineWidth = 1
    const gridSpacing = Math.pow(2, mapZoom) * 5

    for (let i = 0; i < width; i += gridSpacing) {
      ctx.beginPath()
      ctx.moveTo(i, 0)
      ctx.lineTo(i, height)
      ctx.stroke()
    }
    for (let i = 0; i < height; i += gridSpacing) {
      ctx.beginPath()
      ctx.moveTo(0, i)
      ctx.lineTo(width, i)
      ctx.stroke()
    }

    // Draw S-wave (main shaking - larger, more opaque)
    if (showSWave && sWaveRadius > 0) {
      const sWavePixelRadius = kmToPixels(sWaveRadius, mapZoom)
      const epicenterPos = latLngToCanvas(epicenter, mapCenter, mapZoom, width, height)
      
      // Shaking area fill
      const gradient = ctx.createRadialGradient(
        epicenterPos.x, epicenterPos.y, 0,
        epicenterPos.x, epicenterPos.y, sWavePixelRadius
      )
      const baseColor = interpolateIntensityColor(intensityScale, currentIntensity)
      gradient.addColorStop(0, baseColor.replace('rgb', 'rgba').replace(')', ', 0.4)'))
      gradient.addColorStop(0.7, baseColor.replace('rgb', 'rgba').replace(')', ', 0.15)'))
      gradient.addColorStop(1, 'rgba(255, 0, 0, 0)')
      
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(epicenterPos.x, epicenterPos.y, sWavePixelRadius, 0, Math.PI * 2)
      ctx.fill()
      
      // S-wave ring
      ctx.strokeStyle = '#ff3333'
      ctx.lineWidth = 3
      ctx.setLineDash([])
      ctx.beginPath()
      ctx.arc(epicenterPos.x, epicenterPos.y, sWavePixelRadius, 0, Math.PI * 2)
      ctx.stroke()
    }

    // Draw P-wave (faster, detection wave - dashed)
    if (showPWave && pWaveRadius > 0) {
      const pWavePixelRadius = kmToPixels(pWaveRadius, mapZoom)
      const epicenterPos = latLngToCanvas(epicenter, mapCenter, mapZoom, width, height)
      
      ctx.strokeStyle = '#3399ff'
      ctx.lineWidth = 2
      ctx.setLineDash([8, 4])
      ctx.beginPath()
      ctx.arc(epicenterPos.x, epicenterPos.y, pWavePixelRadius, 0, Math.PI * 2)
      ctx.stroke()
      ctx.setLineDash([])
    }

    // Draw sensors
    sensors.forEach(sensor => {
      const pos = latLngToCanvas(sensor.position, mapCenter, mapZoom, width, height)
      const reading = sensorReadings.get(sensor.id)
      
      // Sensor background
      const sensorIntensity = reading?.intensity ?? 0
      const sensorColor = sensorIntensity > 0 
        ? getIntensityColor(intensityScale, sensorIntensity)
        : '#333344'
      
      // Outer glow for triggered sensors
      if (reading?.triggered && sensorIntensity > 0) {
        ctx.fillStyle = sensorColor.replace(')', ', 0.3)').replace('rgb', 'rgba').replace('#', '')
        const glowColor = sensorColor + '40'
        ctx.fillStyle = glowColor
        ctx.beginPath()
        ctx.arc(pos.x, pos.y, 18, 0, Math.PI * 2)
        ctx.fill()
      }
      
      // Sensor circle
      ctx.fillStyle = sensorColor
      ctx.beginPath()
      ctx.arc(pos.x, pos.y, 10, 0, Math.PI * 2)
      ctx.fill()
      
      // Sensor border
      ctx.strokeStyle = sensor.isRealSensor ? '#ffffff' : '#888888'
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(pos.x, pos.y, 10, 0, Math.PI * 2)
      ctx.stroke()
      
      // Sensor name
      ctx.fillStyle = '#ffffff'
      ctx.font = '11px sans-serif'
      ctx.textAlign = 'center'
      ctx.fillText(sensor.name, pos.x, pos.y + 24)
      
      // Intensity reading
      if (reading && reading.intensity > 0.1) {
        ctx.font = 'bold 10px sans-serif'
        ctx.fillStyle = '#000000'
        ctx.fillText(reading.intensity.toFixed(1), pos.x, pos.y + 4)
      }
    })

    // Draw epicenter
    const epicenterPos = latLngToCanvas(epicenter, mapCenter, mapZoom, width, height)
    
    // Pulsing animation
    const pulseScale = 1 + Math.sin(currentTime * 3) * 0.2
    
    // Epicenter cross
    ctx.strokeStyle = '#ff0000'
    ctx.lineWidth = 3
    const crossSize = 15 * pulseScale
    
    ctx.beginPath()
    ctx.moveTo(epicenterPos.x - crossSize, epicenterPos.y)
    ctx.lineTo(epicenterPos.x + crossSize, epicenterPos.y)
    ctx.stroke()
    
    ctx.beginPath()
    ctx.moveTo(epicenterPos.x, epicenterPos.y - crossSize)
    ctx.lineTo(epicenterPos.x, epicenterPos.y + crossSize)
    ctx.stroke()
    
    // Epicenter circle
    ctx.strokeStyle = '#ff0000'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.arc(epicenterPos.x, epicenterPos.y, 8 * pulseScale, 0, Math.PI * 2)
    ctx.stroke()

    // Draw location name near epicenter
    ctx.fillStyle = '#ffffff'
    ctx.font = 'bold 12px sans-serif'
    ctx.textAlign = 'left'
    ctx.fillText(earthquakeInfo.locationName, epicenterPos.x + 25, epicenterPos.y + 5)

    // Draw scale bar
    const scaleBarKm = 100
    const scaleBarPixels = kmToPixels(scaleBarKm, mapZoom)
    
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(20, height - 30, scaleBarPixels, 4)
    ctx.font = '11px sans-serif'
    ctx.fillText(`${scaleBarKm} km`, 20, height - 35)

    // Draw wave legend
    ctx.font = '11px sans-serif'
    ctx.textAlign = 'left'
    
    if (showPWave) {
      ctx.strokeStyle = '#3399ff'
      ctx.setLineDash([8, 4])
      ctx.beginPath()
      ctx.moveTo(20, 20)
      ctx.lineTo(50, 20)
      ctx.stroke()
      ctx.setLineDash([])
      ctx.fillStyle = '#3399ff'
      ctx.fillText(`P-wave: ${pWaveRadius.toFixed(0)} km`, 55, 24)
    }
    
    if (showSWave) {
      ctx.strokeStyle = '#ff3333'
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(20, 40)
      ctx.lineTo(50, 40)
      ctx.stroke()
      ctx.fillStyle = '#ff3333'
      ctx.fillText(`S-wave: ${sWaveRadius.toFixed(0)} km`, 55, 44)
    }

    // Draw active warning indicator
    if (activeWarnings.length > 0) {
      const emergencyWarning = activeWarnings.find(w => w.severity === 'emergency')
      if (emergencyWarning) {
        // Flashing border for emergency
        const flash = Math.sin(currentTime * 8) > 0
        if (flash) {
          ctx.strokeStyle = '#ff0000'
          ctx.lineWidth = 4
          ctx.strokeRect(2, 2, width - 4, height - 4)
        }
      }
    }

  }, [
    epicenter, mapZoom, mapCenter, sensors, sensorReadings,
    pWaveRadius, sWaveRadius, showPWave, showSWave,
    intensityScale, currentIntensity, currentTime, earthquakeInfo,
    activeWarnings
  ])

  useEffect(() => {
    drawMap()
    
    // Redraw on resize
    const handleResize = () => drawMap()
    window.addEventListener('resize', handleResize)
    
    return () => window.removeEventListener('resize', handleResize)
  }, [drawMap])

  // Animation loop
  useEffect(() => {
    let animationFrame: number
    
    const animate = () => {
      drawMap()
      animationFrame = requestAnimationFrame(animate)
    }
    
    animationFrame = requestAnimationFrame(animate)
    
    return () => cancelAnimationFrame(animationFrame)
  }, [drawMap])

  return (
    <div 
      ref={containerRef} 
      className={`relative w-full h-full ${className}`}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
      />
      
      {/* Map controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
        <Button
          variant="secondary"
          size="icon"
          onClick={() => setMapZoom(Math.min(15, mapZoom + 1))}
          className="h-8 w-8 bg-card/80 backdrop-blur"
        >
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button
          variant="secondary"
          size="icon"
          onClick={() => setMapZoom(Math.max(1, mapZoom - 1))}
          className="h-8 w-8 bg-card/80 backdrop-blur"
        >
          <ZoomOut className="h-4 w-4" />
        </Button>
        <Button
          variant="secondary"
          size="icon"
          onClick={centerOnEpicenter}
          className="h-8 w-8 bg-card/80 backdrop-blur"
          title="Center on epicenter"
        >
          <Crosshair className="h-4 w-4" />
        </Button>
      </div>
      
      {/* Zoom level indicator */}
      <div className="absolute bottom-4 right-4 bg-card/80 backdrop-blur px-2 py-1 rounded text-xs text-muted-foreground">
        Zoom: {mapZoom.toFixed(1)}x
      </div>
      
      {/* Pan instructions */}
      <div className="absolute bottom-4 left-20 bg-card/80 backdrop-blur px-2 py-1 rounded text-xs text-muted-foreground flex items-center gap-1">
        <Move className="h-3 w-3" />
        Drag to pan, scroll to zoom
      </div>
    </div>
  )
}
