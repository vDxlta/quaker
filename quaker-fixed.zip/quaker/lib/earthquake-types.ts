// Core type definitions for the earthquake simulator

export interface Position {
  lat: number
  lng: number
}

export interface MapBounds {
  north: number
  south: number
  east: number
  west: number
}

// Intensity Scale System
export interface IntensityLevel {
  value: number
  label: string
  color: string
  description: string
}

export interface IntensityScale {
  id: string
  name: string
  levels: IntensityLevel[]
}

// Seismic Sensors
export interface Sensor {
  id: string
  name: string
  position: Position
  isRealSensor: boolean // true = real-world sensor, false = fictional
  stationCode?: string // e.g., "TK.TOKYO" for real sensors
}

export interface SensorReading {
  intensity: number
  pga: number // Peak Ground Acceleration (gal)
  pgv: number // Peak Ground Velocity (kine)
  triggered: boolean
  triggerTime: number | null
  maxIntensity: number
}

export type SensorDisplayMode = 'intensity' | 'pga' | 'pgv' | 'waveform'

// Timeline Events
export type EventType = 
  | 'intensity' 
  | 'text' 
  | 'sound' 
  | 'warning' 
  | 'annotation' 
  | 'sensor' 
  | 'location'

export interface BaseTimelineEvent {
  id: string
  type: EventType
  startTime: number // in seconds
  duration: number // in seconds
  track: number // which track on the timeline
}

export interface IntensityEvent extends BaseTimelineEvent {
  type: 'intensity'
  intensity: number
  easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out'
}

export interface TextEvent extends BaseTimelineEvent {
  type: 'text'
  text: string
  position: 'top' | 'center' | 'bottom' | 'custom'
  customPosition?: { x: number; y: number }
  fontSize: 'small' | 'medium' | 'large' | 'xlarge'
  style: 'normal' | 'urgent' | 'info' | 'warning'
}

export interface SoundEvent extends BaseTimelineEvent {
  type: 'sound'
  soundType: 'alarm' | 'siren' | 'beep' | 'rumble' | 'custom'
  volume: number // 0-1
  soundId?: string // Reference to saved sound in soundboard
  customUrl?: string
}

// Soundboard - saved audio for reuse
export interface SavedSound {
  id: string
  name: string
  dataUrl: string // Base64 encoded audio data
  duration: number
  createdAt: number
}

export interface WarningEvent extends BaseTimelineEvent {
  type: 'warning'
  warningType: 'eew' | 'tsunami' | 'intensity-alert' | 'long-period' | 'custom'
  severity: 'advisory' | 'warning' | 'emergency'
  title: string
  message: string
  regions?: string[]
}

export interface AnnotationEvent extends BaseTimelineEvent {
  type: 'annotation'
  text: string
  position: Position
  showLine: boolean
}

export interface SensorEvent extends BaseTimelineEvent {
  type: 'sensor'
  sensorId: string
  action: 'add' | 'remove' | 'highlight'
}

export interface LocationEvent extends BaseTimelineEvent {
  type: 'location'
  name: string
  position: Position
  markerStyle: 'pin' | 'circle' | 'star'
}

export type TimelineEvent = 
  | IntensityEvent 
  | TextEvent 
  | SoundEvent 
  | WarningEvent 
  | AnnotationEvent 
  | SensorEvent 
  | LocationEvent

// Wave propagation
export interface WaveState {
  pWaveRadius: number // km
  sWaveRadius: number // km
  pWaveSpeed: number // km/s
  sWaveSpeed: number // km/s
}

// Active Warning for sidebar display
export interface ActiveWarning {
  id: string
  type: 'eew' | 'tsunami' | 'intensity-alert' | 'long-period' | 'custom'
  severity: 'advisory' | 'warning' | 'emergency'
  title: string
  message: string
  active: boolean
}

// Earthquake Info for sidebar
export interface EarthquakeInfo {
  magnitude: number
  depth: number // km
  locationName: string
  originTime: number // timestamp in scenario
  epicenter: Position
}

// Project/Scenario
export interface Scenario {
  id: string
  name: string
  duration: number // total duration in seconds
  earthquakeInfo: EarthquakeInfo
  events: TimelineEvent[]
  sensors: Sensor[]
  intensityScale: IntensityScale
  mapSettings: {
    center: Position
    zoom: number
    bounds?: MapBounds
  }
  waveSettings: {
    pWaveSpeed: number
    sWaveSpeed: number
    showPWave: boolean
    showSWave: boolean
  }
}

// Export settings
export interface ExportSettings {
  resolution: '720p' | '1080p' | '1440p' | '4k'
  frameRate: 30 | 60
  format: 'webm' | 'mp4'
  includeAudio: boolean
}

export const RESOLUTION_MAP: Record<ExportSettings['resolution'], { width: number; height: number }> = {
  '720p': { width: 1280, height: 720 },
  '1080p': { width: 1920, height: 1080 },
  '1440p': { width: 2560, height: 1440 },
  '4k': { width: 3840, height: 2160 }
}
