import type { Position, Sensor, SensorReading } from './earthquake-types'

// Default wave speeds (km/s)
export const DEFAULT_P_WAVE_SPEED = 6.5 // km/s
export const DEFAULT_S_WAVE_SPEED = 3.7 // km/s

// Calculate distance between two points using Haversine formula
export function calculateDistance(pos1: Position, pos2: Position): number {
  const R = 6371 // Earth's radius in km
  const dLat = toRad(pos2.lat - pos1.lat)
  const dLon = toRad(pos2.lng - pos1.lng)
  
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(pos1.lat)) * Math.cos(toRad(pos2.lat)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2)
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

function toRad(deg: number): number {
  return deg * (Math.PI / 180)
}

// Calculate wave radius at a given time
export function calculateWaveRadius(
  elapsedTime: number, // seconds since earthquake origin
  waveSpeed: number // km/s
): number {
  return elapsedTime * waveSpeed
}

// Check if a wave has reached a specific position
export function hasWaveReached(
  epicenter: Position,
  targetPosition: Position,
  waveRadius: number
): boolean {
  const distance = calculateDistance(epicenter, targetPosition)
  return waveRadius >= distance
}

// Calculate arrival time of wave at a position
export function calculateArrivalTime(
  epicenter: Position,
  targetPosition: Position,
  waveSpeed: number
): number {
  const distance = calculateDistance(epicenter, targetPosition)
  return distance / waveSpeed
}

// Calculate intensity attenuation with distance
// Uses a simplified intensity attenuation model
export function calculateAttenuatedIntensity(
  epicenterIntensity: number,
  distance: number, // km from epicenter
  depth: number // km depth of earthquake
): number {
  // Hypocentral distance
  const hypoDistance = Math.sqrt(distance * distance + depth * depth)
  
  // Simple attenuation model: intensity decreases logarithmically with distance
  // Based on: I = I0 - 3 * log10(R/R0) where R0 is reference distance
  const R0 = 10 // reference distance in km
  const attenuation = 3 * Math.log10(Math.max(hypoDistance, R0) / R0)
  
  return Math.max(0, epicenterIntensity - attenuation)
}

// Convert intensity to PGA (Peak Ground Acceleration) in gal
// Using simplified relationship (approximate)
export function intensityToPGA(intensity: number): number {
  // Approximate conversion based on JMA scale
  // PGA (gal) ≈ 10^(0.5 * intensity - 0.6)
  return Math.pow(10, 0.5 * intensity - 0.6)
}

// Convert intensity to PGV (Peak Ground Velocity) in kine (cm/s)
export function intensityToPGV(intensity: number): number {
  // Approximate conversion
  // PGV (kine) ≈ 10^(0.5 * intensity - 1.5)
  return Math.pow(10, 0.5 * intensity - 1.5)
}

// Update sensor readings based on wave propagation
export function updateSensorReadings(
  sensors: Sensor[],
  epicenter: Position,
  currentTime: number,
  originTime: number,
  pWaveSpeed: number,
  sWaveSpeed: number,
  baseIntensity: number,
  depth: number,
  existingReadings: Map<string, SensorReading>
): Map<string, SensorReading> {
  const elapsedTime = currentTime - originTime
  if (elapsedTime < 0) {
    // Before earthquake, return empty/zeroed readings
    const readings = new Map<string, SensorReading>()
    sensors.forEach(sensor => {
      readings.set(sensor.id, {
        intensity: 0,
        pga: 0,
        pgv: 0,
        triggered: false,
        triggerTime: null,
        maxIntensity: existingReadings.get(sensor.id)?.maxIntensity ?? 0
      })
    })
    return readings
  }

  const pWaveRadius = calculateWaveRadius(elapsedTime, pWaveSpeed)
  const sWaveRadius = calculateWaveRadius(elapsedTime, sWaveSpeed)

  const readings = new Map<string, SensorReading>()

  sensors.forEach(sensor => {
    const distance = calculateDistance(epicenter, sensor.position)
    const existing = existingReadings.get(sensor.id)
    
    // Check if P-wave has arrived (initial detection)
    const pWaveArrived = pWaveRadius >= distance
    // Check if S-wave has arrived (main shaking)
    const sWaveArrived = sWaveRadius >= distance
    
    let currentIntensity = 0
    
    if (sWaveArrived) {
      // S-wave brings main shaking
      const timeSinceSWave = elapsedTime - (distance / sWaveSpeed)
      // Intensity builds up and then decays
      const buildupDuration = 5 // seconds to reach peak
      const decayDuration = 30 // seconds to decay
      
      const attenuatedIntensity = calculateAttenuatedIntensity(baseIntensity, distance, depth)
      
      if (timeSinceSWave < buildupDuration) {
        // Building up
        currentIntensity = attenuatedIntensity * (timeSinceSWave / buildupDuration)
      } else if (timeSinceSWave < buildupDuration + decayDuration) {
        // Decaying
        const decayProgress = (timeSinceSWave - buildupDuration) / decayDuration
        currentIntensity = attenuatedIntensity * (1 - decayProgress * 0.7) // Decay to 30%
      } else {
        // Long tail
        currentIntensity = attenuatedIntensity * 0.3 * Math.exp(-(timeSinceSWave - buildupDuration - decayDuration) / 60)
      }
    } else if (pWaveArrived) {
      // P-wave gives slight initial reading
      currentIntensity = 0.5 // Very minor initial reading
    }

    const maxIntensity = Math.max(existing?.maxIntensity ?? 0, currentIntensity)

    readings.set(sensor.id, {
      intensity: currentIntensity,
      pga: intensityToPGA(currentIntensity),
      pgv: intensityToPGV(currentIntensity),
      triggered: pWaveArrived,
      triggerTime: pWaveArrived ? (existing?.triggerTime ?? originTime + distance / pWaveSpeed) : null,
      maxIntensity
    })
  })

  return readings
}

// Calculate ETA of S-wave to a position (main shaking)
export function calculateSWaveETA(
  epicenter: Position,
  targetPosition: Position,
  currentTime: number,
  originTime: number,
  sWaveSpeed: number
): number | null {
  const distance = calculateDistance(epicenter, targetPosition)
  const arrivalTime = originTime + distance / sWaveSpeed
  const eta = arrivalTime - currentTime
  return eta > 0 ? eta : null
}
