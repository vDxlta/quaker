import type { IntensityScale } from './earthquake-types'

// Japan Meteorological Agency Shindo Scale
export const JMA_SCALE: IntensityScale = {
  id: 'jma',
  name: 'JMA Shindo (Japan)',
  levels: [
    { value: 0, label: '0', color: '#808080', description: 'Imperceptible' },
    { value: 1, label: '1', color: '#00b8ff', description: 'Slight shaking' },
    { value: 2, label: '2', color: '#00ff00', description: 'Light shaking' },
    { value: 3, label: '3', color: '#ffff00', description: 'Moderate shaking' },
    { value: 4, label: '4', color: '#ff9900', description: 'Strong shaking' },
    { value: 5, label: '5-', color: '#ff6600', description: 'Very strong (lower)' },
    { value: 5.5, label: '5+', color: '#ff3300', description: 'Very strong (upper)' },
    { value: 6, label: '6-', color: '#ff0000', description: 'Severe (lower)' },
    { value: 6.5, label: '6+', color: '#cc0000', description: 'Severe (upper)' },
    { value: 7, label: '7', color: '#990099', description: 'Extreme' },
  ]
}

// Modified Mercalli Intensity Scale
export const MERCALLI_SCALE: IntensityScale = {
  id: 'mercalli',
  name: 'Modified Mercalli (MMI)',
  levels: [
    { value: 1, label: 'I', color: '#ffffff', description: 'Not felt' },
    { value: 2, label: 'II', color: '#aef1fe', description: 'Weak' },
    { value: 3, label: 'III', color: '#90d0f8', description: 'Weak' },
    { value: 4, label: 'IV', color: '#8ef9af', description: 'Light' },
    { value: 5, label: 'V', color: '#ffff00', description: 'Moderate' },
    { value: 6, label: 'VI', color: '#ffd700', description: 'Strong' },
    { value: 7, label: 'VII', color: '#ffa500', description: 'Very Strong' },
    { value: 8, label: 'VIII', color: '#ff6600', description: 'Severe' },
    { value: 9, label: 'IX', color: '#ff0000', description: 'Violent' },
    { value: 10, label: 'X', color: '#cc0000', description: 'Extreme' },
    { value: 11, label: 'XI', color: '#990000', description: 'Extreme' },
    { value: 12, label: 'XII', color: '#660000', description: 'Extreme' },
  ]
}

// Richter Magnitude Scale (simplified for intensity display)
export const RICHTER_SCALE: IntensityScale = {
  id: 'richter',
  name: 'Richter Magnitude',
  levels: [
    { value: 1, label: '1.0', color: '#e0e0e0', description: 'Micro' },
    { value: 2, label: '2.0', color: '#c0e0ff', description: 'Minor' },
    { value: 3, label: '3.0', color: '#80c0ff', description: 'Minor' },
    { value: 4, label: '4.0', color: '#00ff00', description: 'Light' },
    { value: 5, label: '5.0', color: '#ffff00', description: 'Moderate' },
    { value: 6, label: '6.0', color: '#ffa500', description: 'Strong' },
    { value: 7, label: '7.0', color: '#ff6600', description: 'Major' },
    { value: 8, label: '8.0', color: '#ff0000', description: 'Great' },
    { value: 9, label: '9.0', color: '#990000', description: 'Great' },
    { value: 10, label: '10.0', color: '#660066', description: 'Massive' },
  ]
}

// Default custom scale template
export const CUSTOM_SCALE_TEMPLATE: IntensityScale = {
  id: 'custom',
  name: 'Custom Scale',
  levels: [
    { value: 0, label: 'None', color: '#808080', description: 'No shaking' },
    { value: 1, label: 'Low', color: '#00ff00', description: 'Low intensity' },
    { value: 2, label: 'Medium', color: '#ffff00', description: 'Medium intensity' },
    { value: 3, label: 'High', color: '#ff6600', description: 'High intensity' },
    { value: 4, label: 'Severe', color: '#ff0000', description: 'Severe intensity' },
    { value: 5, label: 'Extreme', color: '#990099', description: 'Extreme intensity' },
  ]
}

export const PRESET_SCALES: IntensityScale[] = [
  JMA_SCALE,
  MERCALLI_SCALE,
  RICHTER_SCALE,
]

// Helper function to get color for a given intensity value
export function getIntensityColor(scale: IntensityScale, intensity: number): string {
  // Find the closest level at or below the intensity
  const sorted = [...scale.levels].sort((a, b) => b.value - a.value)
  for (const level of sorted) {
    if (intensity >= level.value) {
      return level.color
    }
  }
  return scale.levels[0]?.color ?? '#808080'
}

// Helper function to get label for a given intensity value
export function getIntensityLabel(scale: IntensityScale, intensity: number): string {
  const sorted = [...scale.levels].sort((a, b) => b.value - a.value)
  for (const level of sorted) {
    if (intensity >= level.value) {
      return level.label
    }
  }
  return scale.levels[0]?.label ?? '0'
}

// Helper function to interpolate between two intensity colors
export function interpolateIntensityColor(scale: IntensityScale, intensity: number): string {
  const levels = [...scale.levels].sort((a, b) => a.value - b.value)
  
  // Find surrounding levels
  let lower = levels[0]
  let upper = levels[levels.length - 1]
  
  for (let i = 0; i < levels.length - 1; i++) {
    if (intensity >= levels[i].value && intensity <= levels[i + 1].value) {
      lower = levels[i]
      upper = levels[i + 1]
      break
    }
  }
  
  if (intensity <= lower.value) return lower.color
  if (intensity >= upper.value) return upper.color
  
  // Linear interpolation
  const t = (intensity - lower.value) / (upper.value - lower.value)
  return interpolateColor(lower.color, upper.color, t)
}

function interpolateColor(color1: string, color2: string, t: number): string {
  const c1 = hexToRgb(color1)
  const c2 = hexToRgb(color2)
  
  if (!c1 || !c2) return color1
  
  const r = Math.round(c1.r + (c2.r - c1.r) * t)
  const g = Math.round(c1.g + (c2.g - c1.g) * t)
  const b = Math.round(c1.b + (c2.b - c1.b) * t)
  
  return `rgb(${r}, ${g}, ${b})`
}

function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null
}
