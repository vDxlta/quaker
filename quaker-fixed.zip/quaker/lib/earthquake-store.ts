import { create } from 'zustand'
import type {
  TimelineEvent,
  Sensor,
  SensorReading,
  ActiveWarning,
  EarthquakeInfo,
  IntensityScale,
  Position,
  SensorDisplayMode,
  ExportSettings,
  Scenario,
  SavedSound,
} from './earthquake-types'
import { JMA_SCALE } from './intensity-scales'
import { DEFAULT_P_WAVE_SPEED, DEFAULT_S_WAVE_SPEED } from './wave-calculations'

interface SimulatorState {
  // Playback
  isPlaying: boolean
  currentTime: number
  duration: number
  playbackSpeed: number
  
  // Timeline Events
  events: TimelineEvent[]
  selectedEventId: string | null
  
  // Map State
  epicenter: Position
  mapZoom: number
  mapCenter: Position
  
  // Sensors
  sensors: Sensor[]
  sensorReadings: Map<string, SensorReading>
  sensorDisplayMode: SensorDisplayMode
  
  // Earthquake Info (for sidebar)
  earthquakeInfo: EarthquakeInfo
  
  // Wave Propagation
  pWaveRadius: number
  sWaveRadius: number
  pWaveSpeed: number
  sWaveSpeed: number
  showPWave: boolean
  showSWave: boolean
  
  // Active Warnings (for sidebar)
  activeWarnings: ActiveWarning[]
  
  // Intensity
  currentIntensity: number
  intensityScale: IntensityScale
  
  // UI State
  timelineZoom: number
  sidebarCollapsed: boolean
  settingsPanelOpen: boolean
  eventPanelOpen: boolean
  
  // Export
  isRecording: boolean
  exportProgress: number
  exportSettings: ExportSettings
  
  // Soundboard
  savedSounds: SavedSound[]
  
  // Actions
  play: () => void
  pause: () => void
  stop: () => void
  seek: (time: number) => void
  setPlaybackSpeed: (speed: number) => void
  setDuration: (duration: number) => void
  
  // Event actions
  addEvent: (event: TimelineEvent) => void
  updateEvent: (id: string, updates: Partial<TimelineEvent>) => void
  removeEvent: (id: string) => void
  selectEvent: (id: string | null) => void
  
  // Sensor actions
  addSensor: (sensor: Sensor) => void
  updateSensor: (id: string, updates: Partial<Sensor>) => void
  removeSensor: (id: string) => void
  setSensorDisplayMode: (mode: SensorDisplayMode) => void
  updateSensorReadings: (readings: Map<string, SensorReading>) => void
  
  // Map actions
  setEpicenter: (position: Position) => void
  setMapZoom: (zoom: number) => void
  setMapCenter: (center: Position) => void
  
  // Wave actions
  setPWaveRadius: (radius: number) => void
  setSWaveRadius: (radius: number) => void
  setWaveSpeeds: (pSpeed: number, sSpeed: number) => void
  setShowWaves: (showP: boolean, showS: boolean) => void
  
  // Earthquake info actions
  setEarthquakeInfo: (info: Partial<EarthquakeInfo>) => void
  
  // Warning actions
  setActiveWarnings: (warnings: ActiveWarning[]) => void
  addWarning: (warning: ActiveWarning) => void
  removeWarning: (id: string) => void
  
  // Intensity actions
  setCurrentIntensity: (intensity: number) => void
  setIntensityScale: (scale: IntensityScale) => void
  
  // UI actions
  setTimelineZoom: (zoom: number) => void
  toggleSidebar: () => void
  setSettingsPanelOpen: (open: boolean) => void
  setEventPanelOpen: (open: boolean) => void
  
  // Export actions
  setIsRecording: (recording: boolean) => void
  setExportProgress: (progress: number) => void
  setExportSettings: (settings: Partial<ExportSettings>) => void
  
  // Soundboard actions
  addSound: (sound: SavedSound) => void
  removeSound: (id: string) => void
  loadSoundsFromStorage: () => void
  saveSoundsToStorage: () => void
  
  // Scenario actions
  loadScenario: (scenario: Scenario) => void
  exportScenario: () => Scenario
  resetScenario: () => void
}

const defaultEarthquakeInfo: EarthquakeInfo = {
  magnitude: 7.0,
  depth: 10,
  locationName: 'Pacific Ocean',
  originTime: 5,
  epicenter: { lat: 35.6762, lng: 139.6503 }
}

const defaultExportSettings: ExportSettings = {
  resolution: '1080p',
  frameRate: 30,
  format: 'webm',
  includeAudio: true
}

export const useSimulatorStore = create<SimulatorState>((set, get) => ({
  // Initial state
  isPlaying: false,
  currentTime: 0,
  duration: 120,
  playbackSpeed: 1,
  
  events: [],
  selectedEventId: null,
  
  epicenter: { lat: 35.6762, lng: 139.6503 },
  mapZoom: 6,
  mapCenter: { lat: 35.6762, lng: 139.6503 },
  
  sensors: [],
  sensorReadings: new Map(),
  sensorDisplayMode: 'intensity',
  
  earthquakeInfo: defaultEarthquakeInfo,
  
  pWaveRadius: 0,
  sWaveRadius: 0,
  pWaveSpeed: DEFAULT_P_WAVE_SPEED,
  sWaveSpeed: DEFAULT_S_WAVE_SPEED,
  showPWave: true,
  showSWave: true,
  
  activeWarnings: [],
  
  currentIntensity: 0,
  intensityScale: JMA_SCALE,
  
  timelineZoom: 1,
  sidebarCollapsed: false,
  settingsPanelOpen: false,
  eventPanelOpen: false,
  
  isRecording: false,
  exportProgress: 0,
  exportSettings: defaultExportSettings,
  
  savedSounds: [],
  
  // Playback actions
  play: () => set({ isPlaying: true }),
  pause: () => set({ isPlaying: false }),
  stop: () => set({ isPlaying: false, currentTime: 0 }),
  seek: (time) => set({ currentTime: Math.max(0, Math.min(time, get().duration)) }),
  setPlaybackSpeed: (speed) => set({ playbackSpeed: speed }),
  setDuration: (duration) => set({ duration }),
  
  // Event actions
  addEvent: (event) => set((state) => ({ events: [...state.events, event] })),
  updateEvent: (id, updates) => set((state) => ({
    events: state.events.map(e => e.id === id ? { ...e, ...updates } as TimelineEvent : e)
  })),
  removeEvent: (id) => set((state) => ({
    events: state.events.filter(e => e.id !== id),
    selectedEventId: state.selectedEventId === id ? null : state.selectedEventId
  })),
  selectEvent: (id) => set({ selectedEventId: id }),
  
  // Sensor actions
  addSensor: (sensor) => set((state) => ({ sensors: [...state.sensors, sensor] })),
  updateSensor: (id, updates) => set((state) => ({
    sensors: state.sensors.map(s => s.id === id ? { ...s, ...updates } : s)
  })),
  removeSensor: (id) => set((state) => ({
    sensors: state.sensors.filter(s => s.id !== id)
  })),
  setSensorDisplayMode: (mode) => set({ sensorDisplayMode: mode }),
  updateSensorReadings: (readings) => set({ sensorReadings: readings }),
  
  // Map actions
  setEpicenter: (position) => set({ epicenter: position }),
  setMapZoom: (zoom) => set({ mapZoom: zoom }),
  setMapCenter: (center) => set({ mapCenter: center }),
  
  // Wave actions
  setPWaveRadius: (radius) => set({ pWaveRadius: radius }),
  setSWaveRadius: (radius) => set({ sWaveRadius: radius }),
  setWaveSpeeds: (pSpeed, sSpeed) => set({ pWaveSpeed: pSpeed, sWaveSpeed: sSpeed }),
  setShowWaves: (showP, showS) => set({ showPWave: showP, showSWave: showS }),
  
  // Earthquake info actions
  setEarthquakeInfo: (info) => set((state) => ({
    earthquakeInfo: { ...state.earthquakeInfo, ...info }
  })),
  
  // Warning actions
  setActiveWarnings: (warnings) => set({ activeWarnings: warnings }),
  addWarning: (warning) => set((state) => ({
    activeWarnings: [...state.activeWarnings, warning]
  })),
  removeWarning: (id) => set((state) => ({
    activeWarnings: state.activeWarnings.filter(w => w.id !== id)
  })),
  
  // Intensity actions
  setCurrentIntensity: (intensity) => set({ currentIntensity: intensity }),
  setIntensityScale: (scale) => set({ intensityScale: scale }),
  
  // UI actions
  setTimelineZoom: (zoom) => set({ timelineZoom: zoom }),
  toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
  setSettingsPanelOpen: (open) => set({ settingsPanelOpen: open }),
  setEventPanelOpen: (open) => set({ eventPanelOpen: open }),
  
  // Export actions
  setIsRecording: (recording) => set({ isRecording: recording }),
  setExportProgress: (progress) => set({ exportProgress: progress }),
  setExportSettings: (settings) => set((state) => ({
    exportSettings: { ...state.exportSettings, ...settings }
  })),
  
  // Soundboard actions
  addSound: (sound) => {
    set((state) => ({ savedSounds: [...state.savedSounds, sound] }))
  },
  removeSound: (id) => {
    set((state) => ({ savedSounds: state.savedSounds.filter(s => s.id !== id) }))
  },
  loadSoundsFromStorage: () => {
    // Sounds are kept in memory only (base64 audio is too large for localStorage)
  },
  saveSoundsToStorage: () => {
    // No-op: sounds are in-memory only
  },
  
  // Scenario actions
  loadScenario: (scenario) => set({
    duration: scenario.duration,
    earthquakeInfo: scenario.earthquakeInfo,
    events: scenario.events,
    sensors: scenario.sensors,
    intensityScale: scenario.intensityScale,
    mapCenter: scenario.mapSettings.center,
    mapZoom: scenario.mapSettings.zoom,
    epicenter: scenario.earthquakeInfo.epicenter,
    pWaveSpeed: scenario.waveSettings.pWaveSpeed,
    sWaveSpeed: scenario.waveSettings.sWaveSpeed,
    showPWave: scenario.waveSettings.showPWave,
    showSWave: scenario.waveSettings.showSWave,
    currentTime: 0,
    isPlaying: false,
    pWaveRadius: 0,
    sWaveRadius: 0,
    activeWarnings: [],
    currentIntensity: 0,
  }),
  
  exportScenario: () => {
    const state = get()
    return {
      id: crypto.randomUUID(),
      name: `Earthquake Scenario - ${new Date().toISOString()}`,
      duration: state.duration,
      earthquakeInfo: state.earthquakeInfo,
      events: state.events,
      sensors: state.sensors,
      intensityScale: state.intensityScale,
      mapSettings: {
        center: state.mapCenter,
        zoom: state.mapZoom,
      },
      waveSettings: {
        pWaveSpeed: state.pWaveSpeed,
        sWaveSpeed: state.sWaveSpeed,
        showPWave: state.showPWave,
        showSWave: state.showSWave,
      }
    }
  },
  
  resetScenario: () => set({
    events: [],
    sensors: [],
    currentTime: 0,
    isPlaying: false,
    pWaveRadius: 0,
    sWaveRadius: 0,
    activeWarnings: [],
    currentIntensity: 0,
    earthquakeInfo: defaultEarthquakeInfo,
    sensorReadings: new Map(),
  })
}))
