import { EarthquakeSimulator } from '@/components/earthquake-simulator/simulator'

export default function Home() {
  return <EarthquakeSimulator />
}
